function [omega0,harm_vec,r2_vec] = CHS_pitch_def(omega_vec,r2_vec,omega0_int,L)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implements the definition of the Closest Harmonic Spectrum (CHS) from
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% INPUT
% omega_vec             -       vector of frequencies, locations of the 
%                               point masses of the inharmonic spectrum.
% r2_vec                -       corresponding vector of powers.
%
% INPUT (optional)
% omega0_int            -       expected interval for the CHS fundamental
%                               frequency, given as a 1-times-2 vector.
% L                     -       maximum harmonic order.
%
% OUTPUT 
% omega0                -       the CHS fundamental frequency.
% harm_vec              -       corresponding harmonic frequencies.
% r2_vec                -       corresponding powers (identical to input).
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
if nargin<4
    d = min(diff(omega_vec));
    L = round(max(omega_vec)/d);
end
if nargin<3
    omega0_int = d*[0.6,1.5];
end
omega_vec = omega_vec(:);
r2_vec = r2_vec(:);
if length(omega_vec)~=length(r2_vec)
   error('vector of frequencies and vector of powers must have the same length') 
end
if L<length(omega_vec)
   error('Maximum harmonic order must be greater than or equal to the number of pointmasses in spectrum') 
end

%%%%% Harmonic orders %%%%
L_vec = (1:L)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%% Minimize optimal transport cost over fundamental frequency %%%%%%%
nbr_omega0 = 10000;
omega0_grid = linspace(omega0_int(1),omega0_int(2),nbr_omega0)';

ones_L = ones(L,1);
ones_length_r2 = ones(length(r2_vec),1);

sine_rep_mat = kron(omega_vec,ones_L');
omega0_high = omega0_int(2);
omega0_low = omega0_int(1);
while omega0_high-omega0_low>1e-13
    omega0_grid = linspace(omega0_low,omega0_high,nbr_omega0)';
    cost_vec = zeros(nbr_omega0,1);
    for k_omega = 1:nbr_omega0
        harm_rep_mat = kron(ones_length_r2,omega0_grid(k_omega)*L_vec');
        cost_vec(k_omega) = r2_vec'*min(abs(sine_rep_mat-harm_rep_mat).^2,[],2);
    end
    [~,min_ind] = min(cost_vec);
    omega0_high = omega0_grid(min(nbr_omega0,min_ind+1));
    omega0_low = omega0_grid(max(1,min_ind-1));
end
omega0 = omega0_grid(min_ind);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Construct corresponding harmonic sequence %%%%%%
harm_rep_mat = kron(ones_length_r2,omega0*L_vec');
[~,harm_orders] = min(abs(sine_rep_mat-harm_rep_mat).^2,[],2);
harm_vec = omega0*harm_orders;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
