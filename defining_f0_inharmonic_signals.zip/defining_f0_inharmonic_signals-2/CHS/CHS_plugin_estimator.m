function [omega0_est,harm_vec,r2_vec] = CHS_plugin_estimator(y,t,K)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implements the plug-in estimate of the fundamental frequency of the 
% signal y using the definition of Closest Harmonic Spectrum (CHS) from
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%
% NOTE: for the maximum likelihood estimate of the sinusoidal frequencies,
% a simple non-linear least squares procedure initialized by peakpicking in
% the periodogram is used. This can be replaced by more efficient methods.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT 
% y                 -       complex-valued signal, vector of length N.
% t                 -       sample times, vector of length N.
% K                 -       number of complex sinusoids in signal.
%
% OUTPUT
% omega0_est        -       CHS plugin estimate of fundamental frequency.
% harm_vec          -       vector of estimated harmonic sinusoids.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Initial maximum likelihood estimates of frequency and amplitudes %%%%
[omega_vec,r_vec] = ml_est_omega_amps(y,t,K);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Estimate fundamental frequency and harmonics as plug-in to definition %
[omega0_est,harm_vec,r2_vec] = CHS_pitch_def(omega_vec,r_vec.^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

%%%%%%%%%%%%%%%%%%%  ML estimation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [omega_vec,r_vec] = ml_est_omega_amps(y,t,K)
%
% Maximum likelihood estimate of frequencies and amplitudes.
%

%%%%% Initial peakpicking in periodogram %%%%%
nfft = 2^18;
fft_grid = (0:nfft-1)'/nfft*2*pi;
Y = abs(fft(y,nfft)).^2;
[PKS,LOCS,W] = findpeaks(Y,'SortStr','descend','NPeaks',K);
omega_vec = sort(fft_grid(LOCS),'ascend');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% Non-linear least squares %%%%%%%%%%%
N = length(y);
A_func = @(omega_vec) exp(1i*t*omega_vec');
sigma2_func = @(omega_vec) 1/N*sum(abs(y-A_func(omega_vec)*(A_func(omega_vec)\y)).^2);
opt_set = optimset('TolX',1e-10);
omega_test = fminsearch(sigma2_func,omega_vec,opt_set);
r_vec = abs(A_func(omega_test)\y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%