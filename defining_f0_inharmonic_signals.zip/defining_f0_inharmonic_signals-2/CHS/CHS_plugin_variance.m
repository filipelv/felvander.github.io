function CHS_var = CHS_plugin_variance(omega_vec,r_vec,harm_order_vec,N,sigma2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the asymptotic variance of the CHS plug-in estimate of the 
% fundamental frequency of the from
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT 
% omega_vec         -       vector of frequencies.
% r_vec             -       vector of magnitudes (absolute value of complex
%                           amplitudes of sinusoidal components).
% harm_order_vec    -       vector of the harmonic orders of the
%                           frequencies.
% N                 -       sample length.
% sigma2            -       variance of additive noise.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


K = length(r_vec);
K2 = harm_order_vec.^2;
r2 = r_vec.^2;

pitch_var = 6*sigma2/(N*(N^2-1)*K2'*r2);

extra_sum = 0;
for k = 1:K
    harm_order1 = harm_order_vec(k);
    inner_sum = 0;
    for ell = 1:K
        harm_order2 = harm_order_vec(ell);
        inner_sum = inner_sum + r2(ell)*ell*(omega_vec(k)*harm_order2-omega_vec(ell)*harm_order1);
    end
    extra_sum = extra_sum + K2(k)*r2(k)*inner_sum^2;
end

extra_var = sigma2*2*extra_sum/(N*(K2'*r2)^4);

CHS_var = pitch_var+extra_var;
end

