%%% Example script for computing the CHS definition of the fundamental
% frequency, as well as the plug-in estimate, from 
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc,clear,close all
%rng(2*pi)

run_simulation = 1; % set to 1 to run Monte Carlo simulation
if run_simulation
    nbr_mc = 100;
    N_vec = (50:50:500);
    nbr_N = length(N_vec);
    N_vec_fine = (50:10:500)';
    nbr_N_fine = length(N_vec_fine);
end

%%%% Maximal harmonic order %%%%%
L = 5;
L_vec = (1:L)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Fundamental frequency %%%%%
omega0 = pi/10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Inharmonicity (string model) %%%%%
beta = 1e-4;
harm_vec = L_vec.*sqrt(1+beta*L_vec.^2);
omega_vec = omega0*harm_vec;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Amplitude and phases of components %%%%%%%
rho = 10;
r_vec = exp(-1/rho*((1:L)'-L/2).^2);
phi_vec = rand(L,1)*2*pi;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Remove the fourth component (missing harmonic) %%%%%%%%
r_vec(4) = [];
phi_vec(4) = [];
omega_vec(4) = [];
L_vec(4) = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Compute CHS definition %%%%%%%%%%%%%%%%%%%
[chs_omega0,chs_harm_vec,chs_r2_vec] = CHS_pitch_def(omega_vec,r_vec.^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
subplot(211)
stem(omega_vec,r_vec.^2,'linewidth',1.5)
hold on
stem(chs_harm_vec,chs_r2_vec,'linewidth',1.5)
hold off
grid on
xlabel('\omega'),ylabel('power')
legend('inharmonic spectrum','CHS')
title('CHS definition')

%% Estimation on noisy data 

%%%%% Sampling and noise parameters %%%%%%
N = 500;
t = (0:N-1)';
SNR = 10;
sigma2_tilde = 10^(-SNR/10)*sum(r_vec.^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Noise-free signal waveform %%%%%%%%%%%%%
X = exp(1i*t*omega_vec');
Xs = X*diag(r_vec.*exp(1i*phi_vec));
xs = X*(r_vec.*exp(1i*phi_vec));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Noisy signal %%%%%%%%%%%%%
e = sqrt(sigma2_tilde/2)*randn(N,2)*[1;1i];
y = xs + e;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% CHS plug-in estimate %%%%%%
nbr_of_sinusoids = L-1; % Needed for the ML estimate of sinusoidal frequencies
[chs_omega0_est,chs_harm_vec_est,r2_vec_est] = CHS_plugin_estimator(y,t,nbr_of_sinusoids);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Compute asymptotic variance of plug-in estimate %%%%%%%%%%
harm_order_vec = L_vec;
CHS_var = CHS_plugin_variance(omega_vec,r_vec,harm_order_vec,N,sigma2_tilde);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
subplot(212)
stem(omega_vec,r_vec.^2,'linewidth',1.5)
hold on
stem(chs_harm_vec_est,r2_vec_est,'linewidth',1.5)
hold off
grid on
xlabel('\omega'),ylabel('power')
legend('inharmonic spectrum','CHS plug-in')
title('CHS plug-in estimate (noisy data)')

omega0_error = chs_omega0_est-chs_omega0;
fprintf('Deviation from pseudo-true omega0: %.3E\n',omega0_error)
fprintf('Divided by (root) asymptotic variance: %.3f\n',omega0_error/sqrt(CHS_var))

%%
if run_simulation
    chs_asymp_var_vec = zeros(nbr_N_fine,1);
    for kn = 1:nbr_N_fine
        N = N_vec_fine(kn);
        CHS_var = CHS_plugin_variance(omega_vec,r_vec,harm_order_vec,N,sigma2_tilde);
        chs_asymp_var_vec(kn) = CHS_var;
    end
    figure(2)
    hasympchs = semilogy(N_vec_fine,chs_asymp_var_vec,'linewidth',1.5);
    grid on,xlabel('N'),ylabel('MSE')
    legend('asymptotic CHS variance','Location','Northeast')
    drawnow,pause(0.1)
    
    omega0_est_mat = zeros(nbr_mc,nbr_N);
    mse_vec = zeros(nbr_N,1);
    for kn = 1:nbr_N
        N = N_vec(kn);
        t = (0:N-1)';
        X = exp(1i*t*omega_vec');
        Xs = X*diag(r_vec.*exp(1i*phi_vec));
        xs = X*(r_vec.*exp(1i*phi_vec));
        
        for kmc = 1:nbr_mc
            if mod(kmc-1,10)==0
                fprintf('MC %d of %d, N %d of %d\n',kmc,nbr_mc,kn,nbr_N)
            end
            e = sqrt(sigma2_tilde/2)*randn(N,2)*[1;1i];
            y = xs + e;
            
            [chs_omega0_est,chs_harm_vec_est,r2_vec_est] = CHS_plugin_estimator(y,t,nbr_of_sinusoids);
            omega0_est_mat(kmc,kn) = chs_omega0_est;
            if chs_omega0_est<0.2
               'as' 
            end
        end
        temp_mse = mean(abs(omega0_est_mat(:,kn)-chs_omega0).^2);
        mse_vec(kn) = temp_mse;
        figure(2)
        hold on
        homega0est=plot(N,temp_mse,'ko','linewidth',1.5);
        if kn==1
            legend('asymptotic CHS variance','estimate MSE','Location','Northeast')
        end
        drawnow
        pause(0.1)
        hold off
    end
    
end