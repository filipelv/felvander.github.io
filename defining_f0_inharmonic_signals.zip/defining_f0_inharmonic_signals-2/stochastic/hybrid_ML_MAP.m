function [omega0,delta] = hybrid_ML_MAP(y,t,harm_order_vec,sigma2_delta,omega_vec_in)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implements the hybrid ML/MAP estimator of the fundamental frequency and 
% inharmonicity parameters, where the inharmonicity parameters are 
% zero-mean Gaussian with variance sigma2_delta.
%
% From:
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT
% y                     -       signal vector.
% t                     -       vector of sampling times.
% harm_order_vec        -       vector of harmonic orders.
% sigma2_delta          -       variance of the inharmonicity parameters.
% 
% INPUT (optional)
% omega_vec_in          -       initial guess of frequencies for the
%                               sinusoidal components. If excluded, this is
%                               replaced by peak-picking in the
%                               periodogram.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = length(y);
K_vec = harm_order_vec(:);
sum_k2 = sum(K_vec.^2);
K = length(harm_order_vec);

%%% If no initial guess of frequencies, replace by periodogram estimates %%
if nargin<5 || isempty(omega_vec_in)
    nfft = 2^18;
    fft_grid = (0:nfft-1)'/nfft*2*pi;
    Y = abs(fft(y,nfft)).^2;
    [PKS,LOCS,W] = findpeaks(Y,'SortStr','descend','NPeaks',K);
    
    omega_vec = sort(fft_grid(LOCS),'ascend');
else
    omega_vec = omega_vec_in;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A_func = @(omega_vec) exp(1i*t*omega_vec');
omega0_func = @(omega_vec) K_vec'*omega_vec/sum_k2;
sigma2_func = @(omega_vec) 1/N*sum(abs(y-A_func(omega_vec)*(A_func(omega_vec)\y)).^2);
cost_func = @(omega_vec) N*log(sigma2_func(omega_vec))+...
    1/(2*sigma2_delta)*sum((omega_vec-K_vec*omega0_func(omega_vec)).^2);

%%%%%% Minimize cost function with respect to sinusoidal frequencies %%%%%%
opt_set = optimset('TolX',1e-10);
omega_test = fminsearch(cost_func,omega_vec,opt_set);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Estimate of fundamental frequency and inharmonicity parameters %%%%%
omega0 = omega0_func(omega_test);
delta = omega_test-K_vec*omega0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
