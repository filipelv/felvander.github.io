function [HCRLB,FIM] = inharmonic_HCRLB(t_grid,omega0,phi,r,sigma2,sigma2_inharm,harm_order_vec)
%
% Computes the hybrid Cramer-Rao-lower bound for an inharmonic model with
% nominal fundamental frequency omega and where inharmonicity parameters
% are zero-mean Gaussian with variance sigma2_inharm.
%
% From:
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% INPUT
% t_grid            -       vector of sampling times
% omega0            -       angular frequency (scalar)
% phi               -       vector of initial phases
% r                 -       vector of magnitudes
% sigma2            -       additive noise variance (scalar)
% sigma2_inharm     -       variance of inharmonicity parameter
% harm_order_vec    -       vector of harmonic orders.
%
% OUTPUT
% HCRLB             -       HCRLB covariance matrix
% FIM               -       Fisher information matrix.
%
% order of parameters: [omega;phi;r;delta], where delta are the
% inharmonicity parameters.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = length(t_grid);
K = length(phi);
if nargin < 7 || isempty(harm_order_vec)
    harm_order_vec = (1:K)';
end

F = 0;
for k_t = 1:N
    t = t_grid(k_t);
    fim_test = hybrid_expected_fim_complex(t,omega0,phi,r,sigma2,sigma2_inharm,harm_order_vec);
    F = F+fim_test;
end

fim2 = [zeros(2*K+1,K);1/sigma2_inharm*eye(K)];
fim2 = [zeros(3*K+1,2*K+1),fim2];
F = F+fim2;

FIM = F;
HCRLB = inv(FIM);
end