%%% Example script for using the hybrid ML/MAP estimator, as well as the
%%% hybrid Cramer-Rao lower bound (HCRLB), from
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc,clear,close all
%rng(2*pi)

%%%% Maximal harmonic order %%%%%
L = 5;
harm_order_vec = (1:L)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Fundamental frequency %%%%%
omega0 = pi/10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Inharmonicity (stochastic) %%%%%
sigma2_delta = 1e-6;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Amplitude and phases of components %%%%%%%
rho = 10;
r_vec = exp(-1/rho*((1:L)'-L/2).^2);
phi_vec = rand(L,1)*2*pi;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Remove the fourth component (missing harmonic) %%%%%%%%
r_vec(4) = [];
phi_vec(4) = [];
harm_order_vec(4) = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Sampling and noise parameters %%%%%%
N = 500;
t = (0:N-1)';
SNR = 10;
sigma2 = 10^(-SNR/10)*sum(r_vec.^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Simulations %%%%%%%%
nbr_mc = 1000;
%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute HRCLB matrix %%%%%%
[HCRLB,FIM] = inharmonic_HCRLB(t,omega0,phi_vec,r_vec,sigma2,sigma2_delta,harm_order_vec);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Covariance matrix of fundamental frequency and first inharmonicity parameter
K = length(harm_order_vec);
HCRLB_small = [HCRLB(1,1),HCRLB(1,2*K+2);HCRLB(2*K+2,1),HCRLB(2*K+2,2*K+2)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Run simulation

% Estimate the fundamental frequency, as well as the (stochastic) frequency
% of the first sinusoidal component.
omega0_est_vec = zeros(nbr_mc,1);
first_inharm_est = zeros(nbr_mc,1);
first_sine_est = zeros(nbr_mc,1);

first_inharm_save = zeros(nbr_mc,1);
first_sine_save = zeros(nbr_mc,1);
for kmc = 1:nbr_mc
    if mod(kmc-1,10)==0
        fprintf('MC %d of %d\n',kmc,nbr_mc)
    end
    delta_inharm = sqrt(sigma2_delta)*randn(K,1);
    omega_vec = omega0*harm_order_vec+delta_inharm;
    X = exp(1i*t*omega_vec');
    xs = X*(r_vec.*exp(1i*phi_vec));
    first_sine_save(kmc) = omega_vec(1);
    first_inharm_save(kmc) = delta_inharm(1);
    
    e = sqrt(sigma2/2)*randn(N,2)*[1;1i];
    y = xs + e;
    [omega0_est,delta_est] = hybrid_ML_MAP(y,t,harm_order_vec,sigma2_delta);
    omega0_est_vec(kmc) = omega0_est;
    first_inharm_est(kmc) = delta_est(1);
    first_sine_est(kmc) = omega0_est+delta_est(1);
end

%%

omega0_error = omega0_est_vec-omega0;
first_inharm_error = first_inharm_est-first_inharm_save;
first_sine_est_error = first_sine_est - first_sine_save;

%%% Remove potential outliers for plotting purposes
outlier_indices = find(abs(omega0_error)>10*sqrt(HCRLB_small(1,1)));
omega0_error(outlier_indices) = [];
first_inharm_error(outlier_indices) = [];
first_sine_est_error(outlier_indices) = [];
%%%%%%%


figure(1)
subplot(211)
[Nh,Xh] = hist(omega0_error,50);
est_pdf_omega0 = Nh/sum(Nh)/(Xh(2)-Xh(1));
bar(Xh,est_pdf_omega0)
hold on
plot(linspace(Xh(1),Xh(end),1000),normpdf(linspace(Xh(1),Xh(end),1000),0,sqrt(HCRLB_small(1,1))),...
    'linewidth',1.5)
hold off,grid on,title('\omega_0')
xlabel('error (rad)'),legend('empirical','theory')

subplot(212)
[Nh,Xh] = hist(first_inharm_error,50);
est_pdf_first_inharm = Nh/sum(Nh)/(Xh(2)-Xh(1));
bar(Xh,est_pdf_first_inharm)
hold on
plot(linspace(Xh(1),Xh(end),1000),normpdf(linspace(Xh(1),Xh(end),1000),0,sqrt(HCRLB_small(2,2))),...
    'linewidth',1.5)
hold off,grid on,title('\delta_1')
xlabel('error (rad)'),legend('empirical','theory')

figure(2)
subplot(211)
sine_hcrlb = ones(1,2)*HCRLB_small*ones(2,1);
[Nh,Xh] = hist(first_sine_est_error,50);
est_pdf_first_sine = Nh/sum(Nh)/(Xh(2)-Xh(1));
bar(Xh,est_pdf_first_sine)
hold on
plot(linspace(Xh(1),Xh(end),1000),normpdf(linspace(Xh(1),Xh(end),1000),0,sqrt(sine_hcrlb)),...
    'linewidth',1.5)
hold off,grid on,title('\omega_1 (\omega_0 + \delta_1)')
xlabel('error (rad)'),legend('empirical','theory')

subplot(212)
rho_omega0_delta1 = HCRLB_small(1,2)/sqrt(HCRLB_small(1,1)*HCRLB_small(2,2));
scatter(omega0_error,first_inharm_error)
hold on
href = refline(rho_omega0_delta1,0)
hold off
xlabel('\omega_0 error'),ylabel('\delta_1 error')
legend(href,'theoretical correlation')