function fim_tot = hybrid_expected_fim_complex(t,omega0,phi,r,sigma2,sigma2_inharm,harm_order_vec)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the expected hybrid Fisher information matrix for a sample 
% collected at time t for an inharmonic model with nominal fundamental 
% frequency omega0 and where inharmonicity parameters are zero-mean 
% Gaussian with variance sigma2_inharm.
%
% From:
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% INPUT
% t                 -       sample time (scalar)
% omega0            -       angular frequency (scalar)
% phi               -       vector of initial phases
% r                 -       vector of magnitudes
% sigma2            -       additive noise variance (scalar)
% sigma2_inharm     -       variance of inharmonicity parameter
% harm_order_vec    -       vector of harmonic orders.
%
% OUTPUT
% HCRLB             -       HCRLB covariance matrix
% FIM               -       Fisher information matrix.
%
% order of parameters: [omega;phi;r;delta], where delta are the
% inharmonicity parameters.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


K = length(phi);
K_vec = harm_order_vec(:);

sin_vec = sin(t*(K_vec*omega0)+phi);
cos_vec = cos(t*(K_vec*omega0)+phi);
cos2_vec = cos(2*t*(K_vec*omega0)+2*phi);
sin2_vec = sin(2*t*(K_vec*omega0)+2*phi);

scale_fact = exp(-sigma2_inharm*t^2);

%%%%%%%%%%%%%%%%% Real part  %%%%%%%%%%%%%
% omega-omega
omega_omega = t^2/2*sum((r.*K_vec).^2)-...
    t^2/2*scale_fact.^2*cos2_vec'*(r.*K_vec).^2+...
    t^2*scale_fact*((sin_vec'*(r.*K_vec))^2-sum((sin_vec.*(r.*K_vec)).^2));

% omega - sum
omega_sum = sin_vec'*(r.*K_vec);

% omega - phi
mixed_terms = omega_sum*(sin_vec.*r) - sin_vec.*(r.*K_vec).*(sin_vec.*r);
matched_terms = (0.5-0.5*scale_fact.^2*cos2_vec).*r.^2.*K_vec;
omega_phi = t*(matched_terms + scale_fact*mixed_terms);

% omega - r
mixed_terms = -omega_sum*cos_vec-(-sin_vec.*(r.*K_vec)).*cos_vec;
matched_terms = -.5*sin2_vec.*r.*K_vec;
omega_r = scale_fact*t*(mixed_terms+scale_fact*matched_terms);

% omega - delta
omega_delta = t*omega_phi;

% put together
omega_others = [omega_phi;omega_r;omega_delta];

% "basic"-FIM, correlation between components
grad_vec = [-r.*sin_vec;cos_vec;-t*r.*sin_vec;];
small_fim = scale_fact*(grad_vec*grad_vec');

% Auto terms
for k = 1:K
   small_fim(k,k+K) = -.5*r(k)*scale_fact.^2*sin2_vec(k); % phi - r
   small_fim(k,k+2*K) = r(k)^2*t*(0.5-0.5*scale_fact.^2*cos2_vec(k)); % phi - delta
   small_fim(k+K,k+2*K)= -.5*r(k)*t*scale_fact.^2*sin2_vec(k); % r - delta
   
   small_fim(k,k) = r(k)^2*(0.5-0.5*scale_fact.^2*cos2_vec(k)); % phi - phi
   small_fim(k+K,k+K) = (0.5+0.5*scale_fact.^2*cos2_vec(k)); % r - r
   small_fim(k+2*K,k+2*K) = r(k)^2*t^2*(0.5-0.5*scale_fact.^2*cos2_vec(k)); % delta - delta
   
   % mirror
   small_fim(k+K,k) = small_fim(k,k+K);
   small_fim(k+2*K,k) = small_fim(k,k+2*K);
   small_fim(k+2*K,k+K) = small_fim(k+K,k+2*K);
end

F = small_fim;
F = [zeros(1,3*K);small_fim];
F = [zeros(3*K+1,1),F];

F(1,1) = omega_omega;
F(1,2:end)= omega_others';
F(2:end,1)= omega_others;

fim_real = 2/sigma2*F;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%% Imaginary part  %%%%%%%%%%%%%%%%%%%%


% omega-omega
omega_omega = t^2/2*sum((r.*K_vec).^2)+...
    t^2/2*scale_fact.^2*cos2_vec'*(r.*K_vec).^2+...
    t^2*scale_fact*((cos_vec'*(r.*K_vec))^2-sum((cos_vec.*(r.*K_vec)).^2));

% omega - sum
omega_sum = cos_vec'*(r.*K_vec);

% omega - phi
mixed_terms = omega_sum*(cos_vec.*r) - cos_vec.*(r.*K_vec).*(cos_vec.*r);
matched_terms = (0.5+0.5*scale_fact.^2*cos2_vec).*r.^2.*K_vec;
omega_phi = t*(matched_terms + scale_fact*mixed_terms);

% omega - r
mixed_terms = omega_sum*sin_vec-(cos_vec.*(r.*K_vec)).*sin_vec;
matched_terms = .5*sin2_vec.*r.*K_vec;
omega_r = scale_fact*t*(mixed_terms+scale_fact*matched_terms);

% omega - delta
omega_delta = t*omega_phi;

% put together
omega_others = [omega_phi;omega_r;omega_delta];

% "basic"-FIM, correlation between components
grad_vec = [r.*cos_vec;sin_vec;t*r.*cos_vec;];
small_fim = scale_fact*(grad_vec*grad_vec');

% Auto terms
for k = 1:K
   small_fim(k,k+K) = .5*r(k)*scale_fact.^2*sin2_vec(k); % phi - r
   small_fim(k,k+2*K) = r(k)^2*t*(0.5+0.5*scale_fact.^2*cos2_vec(k)); % phi - delta
   small_fim(k+K,k+2*K)= .5*r(k)*t*scale_fact.^2*sin2_vec(k); % r - delta
   
   small_fim(k,k) = r(k)^2*(0.5+0.5*scale_fact.^2*cos2_vec(k)); % phi - phi
   small_fim(k+K,k+K) = (0.5-0.5*scale_fact.^2*cos2_vec(k)); % r - r
   small_fim(k+2*K,k+2*K) = r(k)^2*t^2*(0.5+0.5*scale_fact.^2*cos2_vec(k)); % delta - delta
   
   % mirror
   small_fim(k+K,k) = small_fim(k,k+K);
   small_fim(k+2*K,k) = small_fim(k,k+2*K);
   small_fim(k+2*K,k+K) = small_fim(k+K,k+2*K);
end

F = small_fim;
F = [zeros(1,3*K);small_fim];
F = [zeros(3*K+1,1),F];

F(1,1) = omega_omega;
F(1,2:end)= omega_others';
F(2:end,1)= omega_others;

fim_imag = 2/sigma2*F;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% total %%%%%
fim_tot = fim_real+fim_imag;

%%%%%%%%%%%%%%%%%%%%%
end
