function mcrlb = exact_mcrlb(omega0,r_vec,phi_vec,xi_vec,harm_order_vec,sigma2_true,t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the MCRLB for the pseudo-true fundamental frequency 
% as detailed in
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT (pseudo-true parameters) %%%%%
% omega0                -       pseudo-true fundamental frequency.
% r_vec                 -       vector of pseduo-true magnitudes.
% phi_vec               -       vector of pseudo-true phases.    
%
% INPUT (true signal parameters) %%%%%
% xi_vec                -       vector of differences between the
%                               pseudo-true and true waveform, defined as 
%                               \mu - x, where \mu is the pseudo-true 
%                               harmonic waveform and x is the true 
%                               (inharmonic) waveform.
% harm_order_vec        -       vector of harmonic orders.
% sigma2_true           -       variance of the additive noise
% t                     -       vector of sampling times.
%
% OUTPUT
% mcrlb                 -       the MCRLB for the pseudo-true fundamental
%                               frequency.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(harm_order_vec)
    harm_order_vec = (1:length(omega_vec))';
end
N = length(t);
sigma2 = sigma2_true + 1/N*sum(abs(xi_vec).^2);
FIM = get_harm_fim(t,harm_order_vec,omega0,r_vec,phi_vec);
FIM_mis = get_mis_fim(t,harm_order_vec,omega0,r_vec,phi_vec,xi_vec);
B =  2*sigma2_true/sigma2^2*FIM;
A =  -2/sigma2*FIM - 2/sigma2*FIM_mis;
invA = inv(A);
MCRLB = invA*B*invA;
mcrlb = MCRLB(1);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% FIM for harmonic structure %%%%%%%%%%
function FIM = get_harm_fim(t,harm_order_vec,omega0,r_vec,phi_vec)

K = length(r_vec);
harm_order_vec = harm_order_vec(:);
cos_val = cos(omega0*t*harm_order_vec'+repmat(phi_vec',length(t),1));
sin_val = sin(omega0*t*harm_order_vec'+repmat(phi_vec',length(t),1));

F_real = 0;
for kt = 1:length(t)
   f = zeros(2*K+1,1);
   f(1) = -t(kt)*sin_val(kt,:)*(harm_order_vec.*r_vec);
   f(2:K+1) = -r_vec.*sin_val(kt,:)';
   f(K+2:end) = cos_val(kt,:)';
   F_real = F_real + (f*f');
end

F_imag = 0;
for kt = 1:length(t)
   f = zeros(2*K+1,1);
   f(1) = t(kt)*cos_val(kt,:)*(harm_order_vec.*r_vec);
   f(2:K+1) = r_vec.*cos_val(kt,:)';
   f(K+2:end) = sin_val(kt,:)';
   F_imag = F_imag + (f*f');
end

FIM = F_real + F_imag;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%  FIM for misspecified part %%%%%%%%%%%%%%%%%%%%%%%%
function FIM = get_mis_fim(t,harm_order_vec,omega0,r_vec,phi_vec,xi_vec)
%
K = length(r_vec);
harm_order_vec = harm_order_vec(:);
cos_val = cos(omega0*t*harm_order_vec'+repmat(phi_vec',length(t),1));
sin_val = sin(omega0*t*harm_order_vec'+repmat(phi_vec',length(t),1));

F_real = 0;
for kt = 1:length(t)
    f = zeros(2*K+1,1);
    f(1) = -t(kt)^2*cos_val(kt,:)*(r_vec.*harm_order_vec.^2);
    f(2:K+1) = -t(kt)*r_vec.*harm_order_vec.*cos_val(kt,:)';
    f(K+2:end) = -t(kt).*harm_order_vec.*sin_val(kt,:)';
    F_temp = zeros(2*K+1,2*K+1);
    F_temp(1,:) = f';
    F_temp(:,1) = f;
    
    F_real = F_real + real(xi_vec(kt))*F_temp;
end

F_imag = 0;
for kt = 1:length(t)
    f = zeros(2*K+1,1);
    f(1) = -t(kt)^2*sin_val(kt,:)*(r_vec.*harm_order_vec.^2);
    f(2:K+1) = -t(kt)*r_vec.*harm_order_vec.*sin_val(kt,:)';
    f(K+2:end) = t(kt).*harm_order_vec.*cos_val(kt,:)';
    F_temp = zeros(2*K+1,2*K+1);
    F_temp(1,:) = f';
    F_temp(:,1) = f;
        
    F_imag = F_imag + imag(xi_vec(kt))*F_temp;
end

FIM = F_real+F_imag;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
