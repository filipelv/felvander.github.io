function mcrlb = asymptotic_mcrlb(omega0,r_vec,phi_vec,...
    harm_order_vec,omega_sine_vec,r_sine_vec,phi_sine_vec,N,sigma2_true)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the asymptotic (large sample size) MCRLB for the pseudo-true 
% fundamental frequency as detailed in
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT (pseudo-true parameters) %%%%%
% omega0                -       pseudo-true fundamental frequency.
% r_vec                 -       vector of pseduo-true magnitudes.
% phi_vec               -       vector of pseudo-true phases.
%
% INPUT (true signal parameters) %%%%%
% harm_order_vec        -       vector of harmonic orders.
% omega_sine_vec        -       vector of frequencies of sinusoidal
%                               components.
% r_sine_vec            -       vector 
% phi_sine_vec
% sigma2_true           -       variance of the additive noise
% N                     -       sample length. The signal is assumed to be
%                               sampled at t = 0,1,...,N-1.
% OUTPUT
% mcrlb                 -       the asymptotic MCRLB for the pseudo-true 
%                               fundamental frequency.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(harm_order_vec)
    harm_order_vec = (1:length(omega_vec))';
end

%%%%%%%%%%%%%%% used for computations %%%%%%%%%%%%%
t = (0:N-1)';
delta_omega = omega0*harm_order_vec-omega_sine_vec;
delta_phi = phi_vec-phi_sine_vec;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%% asymptotic C-term %%%%%%%%%%%%%
C = N*(N^2-1)/6*sum((r_vec.*harm_order_vec).^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% asymptotic  D-term  %%%%%%%%%%%%%%%%
delta_vec2 = cos(repmat(delta_phi',N,1)+t*delta_omega')*(harm_order_vec.^2.*r_vec.*r_sine_vec);
D = 2*(N-1)*(N*(N-1)/2*sum((r_vec.*harm_order_vec).^2)-sum(t.*delta_vec2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% asymptotic z_xi (E-term)  %%%%%%%%%%%%%%%%
delta_phase_evolve = repmat(delta_phi',N,1)+t*delta_omega';
part_of_E1 = 2/N*sum(t.*sin(delta_phase_evolve)).^2*(harm_order_vec.^2.*r_sine_vec.^2);
part_of_E2 = 2/N*(sum(t.*cos(delta_phase_evolve)).*(r_sine_vec')-N*(N-1)/2*r_vec').^2*(harm_order_vec.^2);
E = part_of_E1+part_of_E2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% asymptotic alpha_xi (Z-term) %%%%%%%%%%%%%%%
Z  = -2*N*(N-1)*(2*N-1)/6*sum(r_vec.^2.*harm_order_vec.^2)+...
    2*sum(t.^2.*(cos(repmat(delta_phi',N,1)+t*delta_omega')*(harm_order_vec.^2.*r_vec.*r_sine_vec)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% resulting MCRLB %%%%%%%%%%
mcrlb = sigma2_true*(C+E)/(C-E+Z+D)^2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end