%%% Example script for computing the pseudo-true definition of fundamental
% frequency, from
%
% "Defining Fundamental Frequency for Almost Harmonic Signals", Elvander
% and Jakobsson, IEEE Transaction on Signal Processing vol 68, 2020.
%
% DOI: 10.1109/TSP.2020.3035466
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc,clear,close all
%rng(2*pi)

run_simulation = 1; % set to 1 to run Monte Carlo simulation
if run_simulation
    nbr_mc = 100;
    N_vec = (50:50:500);
    nbr_N = length(N_vec);
    N_vec_fine = (50:10:500)';
    nbr_N_fine = length(N_vec_fine);
end

%%%% Maximal harmonic order %%%%%
L = 5;
harm_order_vec = (1:L)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Fundamental frequency %%%%%
omega0 = pi/10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Inharmonicity (string model) %%%%%
beta = 1e-4;
harm_vec = harm_order_vec.*sqrt(1+beta*harm_order_vec.^2);
omega_vec = omega0*harm_vec;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Amplitude and phases of components %%%%%%%
rho = 10;
r_vec = exp(-1/rho*((1:L)'-L/2).^2);
phi_vec = rand(L,1)*2*pi;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Remove the fourth component (missing harmonic) %%%%%%%%
r_vec(4) = [];
phi_vec(4) = [];
omega_vec(4) = [];
harm_order_vec(4) = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Sampling and noise parameters %%%%%%
N = 500;
t = (0:N-1)';
SNR = 10;
sigma2_tilde = 10^(-SNR/10)*sum(r_vec.^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Noise-free signal waveform %%%%%%%%%%%%%
X = exp(1i*t*omega_vec');
Xs = X*diag(r_vec.*exp(1i*phi_vec));
xs = X*(r_vec.*exp(1i*phi_vec));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%% Compute pseudo-true definition %%%%%%%%%%%%%%%%%%%
[omega0_pseudo,r_pseudo,phi_pseudo] = pseudotrue_omega0(omega_vec,r_vec,phi_vec,t,harm_order_vec);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
subplot(211)
stem(omega_vec,r_vec.^2,'linewidth',1.5)
hold on
stem(omega0_pseudo*harm_order_vec,r_pseudo.^2,'linewidth',1.5)
hold off
grid on
xlabel('\omega'),ylabel('power')
legend('inharmonic spectrum','pseudo-true')
title('Pseduo-true harmonic spectrum')

%%% Compute MCRLB and asymptotic MCRLB %%%%
mu = exp(1i*t*(omega0_pseudo*harm_order_vec)')*(r_pseudo.*exp(1i*phi_pseudo));
xi_vec = mu-xs;
mcrlb = exact_mcrlb(omega0_pseudo,r_pseudo,phi_pseudo,xi_vec,harm_order_vec,sigma2_tilde,t);
asymp_mcrlb = asymptotic_mcrlb(omega0_pseudo,r_pseudo,phi_pseudo,...
    harm_order_vec,omega_vec,r_vec,phi_vec,N,sigma2_tilde);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Estimation on noisy data


%%%% Noisy signal %%%%%%%%%%%%%
e = sqrt(sigma2_tilde/2)*randn(N,2)*[1;1i];
y = xs + e;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% Estimate under harmonic assumption %%%%%%
omega_int = omega0*[0.7,1.3];
[omega0_est,alpha_vec_est] = estimate_omega0(y,t,harm_order_vec,omega_int);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
subplot(212)
stem(omega_vec,r_vec.^2,'linewidth',1.5)
hold on
stem(omega0_est*harm_order_vec,abs(alpha_vec_est).^2,'linewidth',1.5)
hold off
grid on
xlabel('\omega'),ylabel('power')
legend('inharmonic spectrum','pseudo-true')
title('Pseudo-true estimate (noisy data)')

omega0_error = omega0_est-omega0_pseudo;
fprintf('Deviation from pseudo-true omega0: %.3E\n',omega0_error)
fprintf('Divided by (root) MCRLB: %.3f\n',omega0_error/sqrt(mcrlb))
fprintf('Divided by (root) asymptotic MCRLB: %.3f\n',omega0_error/sqrt(asymp_mcrlb))

pause(0.1)
drawnow
%%

if run_simulation
    asymp_mcrlb_vec = zeros(nbr_N_fine,1);
    mcrlb_vec = zeros(nbr_N_fine,1);
    omega0_vec = zeros(nbr_N_fine,1);
    for kn = 1:nbr_N_fine
        N = N_vec_fine(kn);
        t = (0:N-1)';
        X = exp(1i*t*omega_vec');
        Xs = X*diag(r_vec.*exp(1i*phi_vec));
        xs = X*(r_vec.*exp(1i*phi_vec));
        
        [omega0_pseudo,r_pseudo,phi_pseudo] = pseudotrue_omega0(omega_vec,r_vec,phi_vec,t,harm_order_vec);
        omega0_vec(kn) = omega0_pseudo;
        
        mu = exp(1i*t*(omega0_pseudo*harm_order_vec)')*(r_pseudo.*exp(1i*phi_pseudo));
        xi_vec = mu-xs;
        mcrlb = exact_mcrlb(omega0_pseudo,r_pseudo,phi_pseudo,xi_vec,harm_order_vec,sigma2_tilde,t);
        asymp_mcrlb = asymptotic_mcrlb(omega0_pseudo,r_pseudo,phi_pseudo,...
            harm_order_vec,omega_vec,r_vec,phi_vec,N,sigma2_tilde);
        mcrlb_vec(kn) = mcrlb;
        asymp_mcrlb_vec(kn) = asymp_mcrlb;
    end
    figure(2)
    hmcrlb = semilogy(N_vec_fine,mcrlb_vec,'linewidth',1.5);
    hold on
    hamcrlb = semilogy(N_vec_fine,asymp_mcrlb_vec,'--','linewidth',1.5);
    hold off
    grid on,xlabel('N'),ylabel('MSE')
    legend('MCRLB','asymptotic MCRLB','Location','Northeast')
    drawnow,pause(0.1)
    
    omega0_est_mat = zeros(nbr_mc,nbr_N);
    mse_vec = zeros(nbr_N,1);
    for kn = 1:nbr_N
        N = N_vec(kn);
        t = (0:N-1)';
        X = exp(1i*t*omega_vec');
        Xs = X*diag(r_vec.*exp(1i*phi_vec));
        xs = X*(r_vec.*exp(1i*phi_vec));
        
        [omega0_pseudo,r_pseudo,phi_pseudo] = pseudotrue_omega0(omega_vec,r_vec,phi_vec,t,harm_order_vec);
        for kmc = 1:nbr_mc
            if mod(kmc-1,10)==0
                fprintf('MC %d of %d, N %d of %d\n',kmc,nbr_mc,kn,nbr_N)
            end
            e = sqrt(sigma2_tilde/2)*randn(N,2)*[1;1i];
            y = xs + e;
            
            omega_int = omega0*[0.7,1.3];
            [omega0_est,alpha_vec_est] = estimate_omega0(y,t,harm_order_vec,omega_int);
            omega0_est_mat(kmc,kn) = omega0_est;
        end
        temp_mse = mean(abs(omega0_est_mat(:,kn)-omega0_pseudo).^2);
        mse_vec(kn) = temp_mse;
        figure(2)
        hold on
        homega0est=plot(N,temp_mse,'ko','linewidth',1.5);
        if kn==1
            legend('MCRLB','asymptotic MCRLB','estimate MSE','Location','Northeast')
        end
        drawnow
        pause(0.1)
        hold off
    end
    
end