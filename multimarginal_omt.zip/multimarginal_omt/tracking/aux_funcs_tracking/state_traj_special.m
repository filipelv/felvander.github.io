function state_trajectory = state_traj_special(x0,x1,t)

Qinv = [12, -6; -6, 4];

eA = [1,1;0,1];

x_tilde = Qinv*(x1-eA*x0);

state_trajectory = zeros(2,length(t));
for kt = 1:length(t)
   t_temp = t(kt);
   x_temp = [1,t_temp;0,1]*x0+[1/2*t_temp^2-1/6*t_temp^3,1/2*t_temp^2;t_temp-1/2*t_temp^2,t_temp]*x_tilde;
   %x_temp = [1,t_temp;0,1]*x0+[1/2*t_temp^2-1/2*t_temp^3,1/2*t_temp^2;t_temp-t_temp^2,t_temp]*x_tilde;
   state_trajectory(:,kt) = x_temp;
end

