%% Plot dynamic estimate
% Estimate
plot_time_axis = (.5:size(interpolant_theta,2)-.5)/size(interpolant_theta,2)*5;
plot_time_axis_gt = (0:nbrSnapshots*m+1)/nbrSnapshots;
figure(1)
subplot(211)
imagesc(plot_time_axis,gridTheta,(interpolant_theta))
cl = flipud(gray);
colormap(cl);
caxis([0,1]),set(gca,'YDir','normal') 
colorbar
xlabel('t (s)'),ylabel('\theta (rad)')
hold on
for k_time = 0:m
    if k_time>0 && k_time<m
        plot([k_time,k_time],[0,2*pi],'r--','Linewidth',1.5)
    elseif k_time == 0
        plot([k_time,k_time]+1e-2,[0,2*pi],'r--','Linewidth',1.5)
    elseif k_time == m
        plot([k_time,k_time]-1e-2,[0,2*pi],'r--','Linewidth',1.5)
    end
end
hold off
title('Estimate with dynamic model')
subplot(212)
imagesc(plot_time_axis,gridV,(interpolant_v))
colorbar,set(gca,'YDir','normal') 
hold on
for k_time = 0:m
    if k_time>0 && k_time<m
        plot([k_time,k_time],[-pi,pi],'r--','Linewidth',1.5)
    elseif k_time == 0
        plot([k_time,k_time]+1e-2,[-pi,pi],'r--','Linewidth',1.5)
    elseif k_time == m
        plot([k_time,k_time]-1e-2,[-pi,pi],'r--','Linewidth',1.5)
    end
end
hold off
caxis([0,1])
colorbar
xlabel('t (s)'),ylabel('v (rad/s)')

% Superimpose indicator for GT location at observation times
figure(1)
for k_m = 0:m
    [~,closest_ind] = min(abs(plot_time_axis_gt-k_m));
    subplot(211)
    hold on
    for kAngle = 1:Nangles
        plot(k_m,theta_traj_cont(kAngle,closest_ind),'bo','Markersize',8)
    end
    hold off
    subplot(212)
    hold on
    for kAngle = 1:Nangles
        plot(k_m,v_traj_cont(kAngle,closest_ind),'bo','Markersize',8)
    end
    hold off
end
hold off

%% Plot static estimate
plot_time_axis = (.5:size(interpolant_theta_static,2)-.5)/size(interpolant_theta_static,2)*5;
cl = flipud(gray);
figure(2)
imagesc(plot_time_axis,gridTheta,(interpolant_theta_static))
colorbar
colormap(cl)
caxis([0,1]),set(gca,'YDir','normal') 
%shading flat
xlabel('time'),ylabel('\theta (rad)')
hold on
for k_time = 0:m
    if k_time>0 && k_time<m
        plot([k_time,k_time],[0,2*pi],'r--','Linewidth',1.5)
    elseif k_time == 0
        plot([k_time,k_time]+1e-2,[0,2*pi],'r--','Linewidth',1.5)
    elseif k_time == m
        plot([k_time,k_time]-1e-2,[0,2*pi],'r--','Linewidth',1.5)
    end
end
hold off
xlabel('t (s)'),ylabel('\theta (rad)')
title('Estimate with static model')
figure(2)
for k_m = 0:m
    [~,closest_ind] = min(abs(plot_time_axis_gt-k_m));
    hold on
    for kAngle = 1:Nangles
        plot(k_m,theta_traj_cont(kAngle,closest_ind),'bo','Markersize',8)
    end
    hold off
end
hold off