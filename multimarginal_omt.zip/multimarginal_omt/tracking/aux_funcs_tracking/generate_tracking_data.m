

%% Generate data from dynamic model

theta_traj_cont = zeros(Nangles,m);
theta_traj_cont(:,1) = theta0;

samplingTime = 1;
tVec = samplingTime*(0:m)';
nbrSnapshots=25; % 50


vIndex = zeros(Nangles,1);
thetaIndex = zeros(Nangles,1);

for kAngle = 1:Nangles
    [~,tempI] = min(abs(v0(kAngle)-gridV));
    vIndex(kAngle) = tempI;
    [~,tempI] = min(abs(theta_traj_cont(kAngle,1)-gridTheta));
    thetaIndex(kAngle) = tempI;
end
v0 = gridV(vIndex)';
v_traj_cont = zeros(Nangles,m);
v_traj_cont(:,1) = v0;
v_spectra=zeros(NV,m);
v_spectra(vIndex, 1)=magnitudes;


theta_spectra=zeros(NTheta,m);
theta0 = gridTheta(thetaIndex);
theta_spectra(thetaIndex, 1)=magnitudes;


spectrum_0 = zeros(NV,NTheta);
for kAngle = 1:length(magnitudes)
   spectrum_0(vIndex(kAngle),thetaIndex(kAngle)) = magnitudes(kAngle);
end

%%
N_fine = nbrSnapshots*m;

spectrum_gt_cell = cell(N_fine+1,1);
spectrum_gt_cell{1} = spectrum_0;
RCell = cell(m,1);
ACell = cell(m,1);

target_acceleration = 5e-3*[-1;1];
cov_counter = 1;
for k=1:N_fine+1
    
    %%%%%%%%%%%%% Move targets %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    acceleration_perturbation = 5*1e-4*(rand(2,1)-.5);
    v_traj_cont(:,k+1) = v_traj_cont(:,k) + target_acceleration+acceleration_perturbation;
    theta_traj_cont(:,k+1) = theta_traj_cont(:,k) + (v_traj_cont(:,k+1)+v_traj_cont(:,k))/2/nbrSnapshots;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%% Map to closest angles on grid (for plotting) %%%%%%%%%%
    thetaIndex = zeros(Nangles,1);
    vIndex = zeros(Nangles,1);
    for kAngle = 1:Nangles
        [~,tempI] = min(abs(theta_traj_cont(kAngle,k+1)-gridTheta));
        thetaIndex(kAngle) = tempI;
        [~,tempI] = min(abs(v_traj_cont(kAngle,k+1)-gridV));
        vIndex(kAngle) = tempI;
    end
    theta_spectra(thetaIndex, k+1)=magnitudes;

    v_spectra(vIndex, k+1)=magnitudes;
    
    temp = zeros(NV,NTheta);
    for kAngle = 1:length(magnitudes)
        temp(vIndex(kAngle),thetaIndex(kAngle)) = magnitudes(kAngle);
    end
    spectrum_gt_cell{k+1} = temp;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Actual steering vectors for current state
    aSim=exp(1i*2*pi*x*[cos(theta_traj_cont(:,k))';sin(theta_traj_cont(:,k)')]/lambda)/sqrt(size(x,1));
        
    % Simulate signal and noise
    s = diag(sqrt(magnitudes))*randn(Nangles,nbrSnapshots);
    e = sqrt(white_noiselevel/2)*(randn(Nsensors,nbrSnapshots) + 1i*randn(Nsensors,nbrSnapshots));
    yMat = aSim*s + 1*e;
    
    % Compute sample covariance matrices
    SCM=yMat*yMat'/nbrSnapshots;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if mod(k-1,nbrSnapshots)==0
        RCell{cov_counter} = SCM;
        ACell{cov_counter}=array_operators;
        cov_counter = cov_counter+1;
    end   
end
%%