function [interpolant_theta] = interpolate_from_transport_cell_static(transport_plan_cell,...
    gridTheta,number_of_points)

number_of_plans = length(transport_plan_cell);
t_total = linspace(0,1,number_of_points+2)';
power_threshold = 1e-10;

NTheta = length(gridTheta);

interpolant_theta = [];

for k_plan = 1:number_of_plans
    fprintf('Computing interpolant corresponding to plan %d of %d\n',k_plan,number_of_plans)
    if k_plan<number_of_plans
       t = t_total(1:end-1); 
    else
        t = t_total; 
    end
    
    t_length = length(t);
    
    transport_plan = transport_plan_cell{k_plan};
    interpolant_spectra = cell(t_length,1);
    
    for kt = 1:t_length
        interpolant_spectra{kt} = zeros(NTheta,1);
    end
    
    nz_inds = find(transport_plan>power_threshold);
    
    mat_ind_mat = zeros(length(nz_inds),2);
    
    for k_ind = 1:length(nz_inds)
        [ind1,ind2] = ind2sub([NTheta,NTheta],nz_inds(k_ind));
        mat_ind_mat(k_ind,:) = [ind1,ind2];
    end
    
    for k_ind = 1:length(nz_inds)
        %fprintf('Ind %d of %d\n',k_ind,length(nz_inds))
        ind1 = mat_ind_mat(k_ind,1);
        x1 = gridTheta(ind1);
        
        ind2 = mat_ind_mat(k_ind,2);
        x2 = gridTheta(ind2);
        
        x_traj = x1*(1-t)+x2*t;
        temp_mass = transport_plan(ind1,ind2);
        
        for kt = 1:t_length
            x_state = x_traj(kt);
            temp_theta = x_state(1);
            [~,theta_ind] =min(abs(temp_theta-gridTheta));
            
            temp_spectrum = interpolant_spectra{kt};
            temp_spectrum(theta_ind) = temp_spectrum(theta_ind)+temp_mass;
            interpolant_spectra{kt} = temp_spectrum;
            
        end
    end
    
    interpolant_theta_inner = zeros(NTheta,length(t));
    for kt = 1:t_length
        interpolant_theta_inner(:,kt) = interpolant_spectra{kt};
    end
    interpolant_theta = [interpolant_theta,interpolant_theta_inner];   
end