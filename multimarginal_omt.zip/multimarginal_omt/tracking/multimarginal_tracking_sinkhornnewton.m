function [Phi,transport_plan_cell,var_args_out] = ...
    multimarginal_tracking_sinkhornnewton(operator_cell,adjoint_cell,Jacobian_cell,r_cell,Cost_cell, epsilon,gamma,tol)
%
% Implementation of the multi-marginal tracking problem in
%
% "Multi-marginal optimal transport using partial information with
% applications in robust localization and sensor fusion", 2020, Elvander et
% al, Section 3.1, as described in Section 3.2 and 5.1.
% (sequentially decoupling cost function).
%
% Implementation: Filip Elvander and Isabel Haasler.
%
%%%%%%%%%%%% INPUT %%%%%%%%%%%%%%
% operator_cell         -   cell of length N_marginals. Each cell should
%                           contain a function handle to the operator G_t,
%                           for t = 1,...,N_marginals. If G_t can be
%                           represented as a matrix G, simply give the
%                           handle as G_t = @(x) G*x.
% adjoint_cell          -   cell of length N_marginals, with each cell
%                           containing a function handle to the adjoint
%                           operator of G_t. If G_t can be represented as a
%                           matrix G, simply give the adjoint as @(y) G'*y.
% Jacobian_cell         -   cell of length N_marginals. Each cell should
%                           contain afunction handle to the part
%                           G_t diag(x) G_t^T of the Jacobian below
%                           equation (39). If the operator G_t can be
%                           represented as a matrix G, simply give the
%                           handle as @(x) G*diag(x)*G';
% r_cell                -   cell of length N_marginals, where each element
%                           r_t, for t = 1,...,N_marginals, is vectorized
%                           and dimension reduced covariance matrix R_t.
%                           Note here that r_t should be in the range of
%                           G_t, i.e., G_t maps spectra to r_t.
%                           NOTE: use the auxilliary function TransformData
%                           to get this.
% Cost_cell             -   cell of length d_dim, containing the cost
%                           function C. If C can be decoupled in d_dim
%                           dimensions, according to Remark 4, then each
%                           element of the cell should contain such a
%                           component. If C is simply a matrix, then
%                           Cost_cell should be a cell of length 1
%                           containing just the matrix C.
% epsilon               -   entropy regularization parameter. If the method
%                           suffers numerical problems, try increasing this
%                           parameter.
% gamma                 -   regularization parameter penalizing measurement
%                           error.
% tol                   -   solver tolerance.
%
%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%
% Phi                   -       matrix of size N_grid \times N_marginals
%                               containing the marginal spectra for each
%                               time point.
% transport_plan_cell   -       cell of length N_marginals-1 containing the
%                               pairwise transport plans for successive
%                               time points.
% var_args_out          -       struct containg the dual variable U, V_left
%                               and V_right necessary for computing all
%                               projections of the multimarginal transport
%                               plan.
%
%%%%%%%%%%%%%
% This version: 8 November 2021.
% Note: this version supports abstract representations of operator and
% adjoint operator as to allow for more efficient computations than
% possible when representing the operator as a matrix.
%%%%%%%%%%%%%
addpath('tensorlab')
if nargin<8
    tol = 1e-5;
end
do_print = 1;
%%%% Number of grid points used to grid the space %%%%%
N_grid = 1;
for kdim = 1:length(Cost_cell)
    N_grid = N_grid*size(Cost_cell{1},2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Number of margianals, i.e., observation times %%%%%%
N_marginals=length(r_cell);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Number of dimensions in which C can be decomposed according to Remark 4
d_dim = length(Cost_cell);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% K = exp(-C/epsilon) %%%%%%%%
K_cell = cell(d_dim,1);
for k_dim = 1:d_dim
    K_cell{k_dim} = exp(-Cost_cell{k_dim}/epsilon);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% K^T %%%%%%%
K_cell_transposed = cellfun(@transpose,K_cell,'un',0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Initialize U = [u_1,u_2,...u_{N_marginals}] %%%%%
U=zeros(N_grid,N_marginals);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Initialize lambda_k, for k = 1,...,N_marginals %%%%%%
LCell=cell(1,N_marginals);
for k_time=1:N_marginals
    LCell{k_time}= zeros(size(r_cell{k_time}));
    U(:,k_time) = exp(adjoint_cell{k_time}(LCell{k_time})/epsilon);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Initialize V_left and V_right %%%%%%%%%%
% these are the right and left factors for u_t in Propostion 2, equation
% above equation (40). Note that V_left(:,t).*V_right(:,t) = v_t, where v_t
% is as in Theorem 1.
V_left=ones(N_grid,N_marginals);
V_right=V_left;
[V_left, V_right] = compute_Vterms_internal(V_left,V_right,K_cell_transposed,K_cell,ones(N_grid,N_marginals),0,0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% start updating the first marginal corresponding to first time instance
k_time=1;
sweep_direction=0;
dU=1;
U_old=U;

% Iteration counter
it=0;


while norm(dU)/norm(U)>tol && it <= 5000
    
    it=it+1;
    
    if do_print && mod(it,100)==0
        fprintf('Sinkhorn iteration %d, variable change %.3E, tolerance %.3E\n',it,norm(dU)/norm(U),tol)
    end
    
    %%%%%%%%%%%%%%% Compute vector v_k using Proposition 2 %%%%%%%%%%%%
    % Sequential computation of factors for efficiency.
    [V_left, V_right] = compute_Vterms_internal(V_left,V_right,K_cell_transposed,K_cell,U,k_time,sweep_direction);
    V = V_left(:,k_time).*V_right(:,k_time);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%% Compute lambda_k %%%%%%%%%%%%%%%%%%%%%%%%
    % Solve using Newton method.
    LCell{k_time} = OMT_Newton_abstract_internal(operator_cell{k_time},adjoint_cell{k_time},...
        Jacobian_cell{k_time},r_cell{k_time},V, LCell{k_time}, epsilon, gamma);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%% Compute u_k %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    U(:,k_time) = exp(adjoint_cell{k_time}(LCell{k_time})/epsilon);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%% Decide sweep direction: sweep_direction = 1 or sweep_direction = -1.
    if it==1
        sweep_direction=1;
    end
    %%%%%%
    %%%%%% If k == N_marginals, another full pass has been performed %%%%%
    if k_time==N_marginals
        sweep_direction=-1;
        dU=U_old-U;
        U_old=U;
    end
    if k_time==1
        sweep_direction=1;
        dU=U_old-U;
        U_old=U;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%% Update next variable %%%%%%%%%%%%%%%%%%%%%%
    k_time=k_time+sweep_direction;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

fprintf('Sinkhorn routine terminated in %d iterations.\n',it)

%disp(['Number of Sinkhorn iterations: ', num2str(it)])

fprintf('Compute marignals and transport plans...')
[Phi,transport_plan_cell] = ...
    marginal_projections_internal(V_left,V_right,K_cell_transposed,K_cell,U);
fprintf('done.\n')
var_args_out = struct;
var_args_out.U = U;
var_args_out.V_left = V_left;
var_args_out.V_right = V_right;
var_args_out.K_cell = K_cell;
var_args_out.K_cell_transposed = K_cell_transposed;
end
%%%%%%%%%%%%%%%%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% INTERNAL AUXILIARY FUNCTIONS %%%%%%%%%%%%

%%%%%%%%%
function [V_left, V_right] = compute_Vterms_internal(V_left,V_right,K_cell_left,K_cell_right,U,k_update,sweep_direction)
%
% Computes the factors left and right of u_t in the projection
% P_t(K\odot U) in Proposition 2, for t = 1,...,N_marginals, represented as two
% matrices.
%
%%%%%%%%%% INPUT %%%%%%%%%%%%%
% V_left        -       matrix of size N_grid\times N_marginals, where
%                       N_grid is the number of points used to grid the
%                       space. Each column corresponds to a left factor as
%                       appearing in the expression for P_t in
%                       Proposition 2.
% V_right       -       As V_left, but instead the right factors for P_t in
%                       Proposition 2.
% K_cell_left   -       cell containing the transposed components of K, if
%                       K can be decoupled as in Remark 4, for efficient
%                       computations. Used for multiplying the left
%                       factors.
% K_cell_right  -       as K_cell_left, but not transposed.
% U             -       matrix of size N_grid\times N_marginals, each
%                       column corresponding to a dual variable u_t, as in
%                       Propostion 2.
% k_update      -       the marginal to be updated, in the range
%                       [1,N_marginals]. Used k_update = 0 for
%                       initialization.
% sweep_direction -     +1 or -1, indicating if a forward or backward pass
%                       is being performed, i.e., if k_update <- k_update+1
%                       or k_update <- k_update-1.
%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%
% V_left           -       updated V_left.
% V_right          -       updated V_right.
%
%
%%%%%%%%%%%%
% This version: 8 November 2021.
%%%%%%%%%%%%
%

[N_grid, N_marginals]=size(U);

if k_update==0
    % Initialization: before any sweep has been performed, we only have
    % right factors.
    V_right(:,N_marginals) = ones(N_grid,1);
    for k=1:N_marginals-1
        j= N_marginals-k;
        V_right(:,j) = Cost_multiplication_internal(K_cell_right,U(:,j+1).*V_right(:,j+1));
    end
elseif k_update==1
    V_right(:,k_update) = Cost_multiplication_internal(K_cell_right,U(:,k_update+1).*V_right(:,k_update+1));
elseif k_update==N_marginals
    V_left(:,k_update) = Cost_multiplication_internal(K_cell_left,U(:,k_update-1).*V_left(:,k_update-1));
else
    if sweep_direction==1
        % Multiply the left factors. Note the transposition.
        V_left(:,k_update) = Cost_multiplication_internal(K_cell_left,U(:,k_update-1).*V_left(:,k_update-1)); %Cost_multiplication(K,U(:,k_update).*V_left(:,k_update-1),Ndim);
    elseif sweep_direction==-1
        % Multiply the right factors.
        V_right(:,k_update) = Cost_multiplication_internal(K_cell_right,U(:,k_update+1).*V_right(:,k_update+1)); %Cost_multiplication(K,U(:,k_update).*V_right(:,k_update+1),Ndim);
    end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%
function lambda=OMT_Newton_abstract_internal(G_operator,G_adjoint,G_Jacobian,r,v,lambda0, epsilon, gamma)
%
%%%%%%%%%%%%%%%
% Newton method for solving equation (38).
% This method uses abstract representations of the operator G, its adjoint,
% and the corresponding part of the Jacobian. This allows for more
% efficient application than allowed by matrix representations.
%%%%%%%%%%%%%%%%%% INPUT %%%%%%%%%%%%%%%%%%%
% G_operator    -       function handle to operator G_t.
% G_adjoint     -       function handle to adjoint operator G_t^T
% G_Jabobian    -       function handle for compution G_t diag(x) G_t^T
% r             -       covariance vector, the measurement.
% v             -       vector depending on other variables.
% lambda0       -       initial value for lambda.
% epsilon       -       entropy regularization parameter.
% gamma         -       regularization parameter penalizing measurement
%                       error.
% tol           -       tolerance for solution.
%%%%%%%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%%%%%
% lambda        -       vector, solution to (38).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 8 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%
scaled_I = eye(length(r))/2/gamma;
lambda=lambda0;

Niter=100;
f=1;
it=0;
while norm(f)>1e-8 && it < Niter
    it=it+1;
    
    u = exp(G_adjoint(lambda)/epsilon);
    vu = v.*u;
    f = G_operator(vu)+lambda/2/gamma-r;
    H = G_Jacobian(vu)/epsilon+scaled_I;
    
    dlambda= -H\f;
    
    % linesearch
    dF = 1;
    lambda_o = lambda;
    F = norm(f);
    nn=1;
    
    while dF>0
        lambda = lambda_o+1/nn*dlambda;
        u = exp(G_adjoint(lambda)/epsilon);
        f = G_operator(v.*u)+lambda/2/gamma-r;
        F_new = norm(f);
        dF = F_new-F;
        nn=2*nn;
        if nn>1e3
            disp('Many line search iterations')
            break;
        end
    end
    
end

if it>10
    disp(['Many Newton iterations: ', num2str(it)])
end

if norm(f)>1e-6
    disp('Newton has not converged')
    [log(norm(f)), log(norm(dlambda)), norm(lambda)]
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function KU = Cost_multiplication_internal(KCell,U)
% Multiplicated each column in U as a tensor with Ndim dimensions with K
% from each dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Efficient computation of matrix-vector products Ku between a matrix K and
% a vector u when K can be decoupled as a tensor product
%
% K = K_1 \otimes K_2 \otimes ... \otimes K_{Ndim}
%
% where \otimes is the Kronecker product, and K_j are matrices of size
%
% (see Remark 4).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 5 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
Ndim=length(KCell);

nbrOfMatrices=size(U,2);
for d=1:Ndim
    Ngrid(d)=size(KCell{d},2);
    Ngrid_full(d)=size(KCell{d},1);
end
N=prod(Ngrid_full);

noReshapeFlag = size(U,1)==Ngrid;
for kMat= 1:nbrOfMatrices
    if noReshapeFlag
        U_array=U(:,kMat);
    else
        U_array=reshape(U(:,kMat),Ngrid);
    end
    temp=U_array;
    for d=1:Ndim
        temp=tmprod(temp,KCell{d},d);
    end
    KU(:,kMat)= reshape(temp,N,1);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Phi,transport_plan_cell] = ...
    marginal_projections_internal(V_left,V_right,KCell_transposed,KCell,U)
% Computes marginal and pairwise projections, i.e., P_t and P_{t_1,t_2},
% according to Proposition 2. Note that P_{t_1,t_2} corresponds to the
% transport plan from time t_1 to time t_2.
%
%%%%%%%%%% INPUT %%%%%%%%%%%%%
% V_left        -       matrix of size N_grid\times N_marginals, where
%                       N_grid is the number of points used to grid the
%                       space. Each column corresponds to a left factor as
%                       appearing in the expression for P_t in
%                       Proposition 2.
% V_right       -       As V_left, but instead the right factors for P_t in
%                       Proposition 2.
% KCell_transposed -    cell containing the transposed components of K, if
%                       K can be decoupled as in Remark 4, for efficient
%                       computations.
% KCell             -   as KCell_transposed, but not transposed.
% U             -       matrix of size N_grid\times N_marginals, each
%                       column corresponding to a dual variable u_t, as in
%                       Propostion 2.
%
%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%
% Phi           -       matrix of N_grid\times N_marginals, containing the
%                       projections P_t, for t = 1,...,N_marginals. These
%                       are the marginal spectra.
% transport_plan_cell - cell of length N_marginals-1. Each element is a
%                       projection P_{t,t+1} for t=1,...,N_marginals-1.
%                       This corresponds to transport plans between t and
%                       t+1, with each transport plan being represented as
%                       a N_grid\times N_grid matrix.
%
%
%%%%%%%%%%%%
% This version: 8 November 2021.
%%%%%%%%%%%%
%
N_grid = size(KCell{1},1);
N_marginals = size(U,2);

if length(KCell)==1
   K = KCell{1};
   K_is_matrix = 1;
else 
    K_is_matrix = 0;
end
% Marginal spectra for each time point
Phi = zeros(N_grid,N_marginals);

% Transport plans for succesive time points
transport_plan_cell = cell(N_marginals-1,1);
sweep_direction=0;
for k_time=1:N_marginals
    [V_left, V_right] = compute_Vterms_internal(V_left,V_right,KCell_transposed,KCell,U,k_time,sweep_direction);
    V = V_left(:,k_time).*V_right(:,k_time);
    % marginal spectrum: marginal projection
    Phi(:,k_time)=V.*U(:,k_time);
    
    % transport plan: pairwise projection
    if k_time<N_marginals
        left_factor = diag(V_left(:,k_time));
        right_factor = diag(V_right(:,k_time+1));
        if K_is_matrix
            % More efficient, diagonal scaling
            middle_factor = repmat(U(:,k_time),1,size(K,1)).*K.*repmat(U(:,k_time+1)',size(K,2),1);
        else
            middle_factor = repmat(U(:,k_time),1,size(KCell{1},1)).*Cost_multiplication_internal(KCell,diag(U(:,k_time+1)));
        end
        transport_plan_cell{k_time} = left_factor*middle_factor*right_factor;
    end
    sweep_direction=1;
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


