%% Script for running dynamical tracking example
% This corresponds to Example 1 and Section 6.1 of
%
% "Multi-marginal optimal transport using partial information with
% applications in robust localization and sensor fusion", 2020, Elvander et
% al.
%
clear,clc,close all

addpath('aux_funcs_tracking')
rng(0)

fprintf('Run tracking problem. Estimate target trajectories based both on dynamical and static models.\n')

% Nbr of targets
Nangles = 2;

% The magnitudes of the signals emitted by the targets
magnitudes = 1+0.5*(rand(Nangles,1)-0.5);

% Initial velocity
v0 = [-1,1]/10;

% Initial angular position
theta0 = [4; 2];

% Grid of angular positions
NTheta = 100;
gridTheta = (1:NTheta)'*2*pi/NTheta;

% Grid of angular velocities
NV = 30;
vRange = 5e-1*pi*[-1,1];
gridV = linspace(vRange(1),vRange(2),NV);

% Sensor array
Nsensors = 5;
x = [[1:(Nsensors-1)/2; zeros(1,(Nsensors-1)/2)],[ zeros(1,(Nsensors+1)/2); 0:(Nsensors-1)/2]]';

% Wavelength
lambda = 1;
% Power of additive noise
white_noiselevel = 1e-1;

% Nbr of observation times for the tracking
m = 5;

%% Covariance operators for the array, mapping spatial spectra to vectorized covariances

a=exp(1i*2*pi*x*[cos(gridTheta');sin(gridTheta')]/lambda)/sqrt(size(x,1));
array_operators=zeros(size(x,1)^2, NTheta);
for k=1:length(gridTheta)
    array_operators(:,k)=reshape((a(:,k)*a(:,k)'),Nsensors^2,1);
end

%% Generate the tracking data

generate_tracking_data


%% Dimension reduction of data and operators

% Yields vectorized real covariance, and corresponding operators
[ r_cell_real, ACell_real ] = TransformData( RCell, ACell );

%% Compute covariance operators

% if we introduce a hidden velocity state, the covariance operators must
% include marginalization of the velocity spectra. Also the adjoint and
% Jacobian must reflect this. More efficient alternative to matrix
% representation.
vec_op = @(mu) mu(:);
operator_cell = cell(1,length(r_cell_real));
adjoint_cell = cell(1,length(r_cell_real));
Jacobian_cell = cell(1,length(r_cell_real));
for kcell = 1:length(r_cell_real)
    G_operator = @(mu) ACell_real{kcell}*sum(reshape(mu(:),NV,NTheta))';
    operator_cell{kcell} = G_operator;
    G_adjoint = @(mu) reshape(repmat(vec_op(ACell_real{kcell}'*mu)',NV,1),NV*NTheta,1);
    adjoint_cell{kcell} = G_adjoint;
    G_Jacobian = @(mu) ACell_real{kcell}*diag(sum(reshape(mu(:),NV,NTheta)))*ACell_real{kcell}';
    Jacobian_cell{kcell} = G_Jacobian;
end


%% Dynamical system: same notation as in paper

A = [0,1;0,0];
W = [1/3,1/2;1/2,1];
Winv = [12, -6; -6, 4];
F = [1,0];

eA1 = [1,1;0,1];

% Cost matrix defined by dynamical system
CostMat = zeros(NTheta*NV,NTheta*NV);
fprintf('Computing cost matrix for dynamical model...')
for kTheta1 = 1:NTheta
    for kV1 = 1:NV
        index1 = (kTheta1-1)*NV + kV1;
        x1 = [gridTheta(kTheta1);gridV(kV1)];
        for kTheta2 = 1:NTheta
           for kV2 = 1:NV
               index2 = (kTheta2-1)*NV + kV2;
               x2 = [gridTheta(kTheta2);gridV(kV2)];
               costVal = (x2-eA1*x1)'*Winv*(x2-eA1*x1);
               CostMat(index1,index2)= costVal;
           end
        end 
    end
end
fprintf('done.\n')

%% Solve OMT tracking problem with dynamics

% Entropy regularization parameter
epsilon=0.1;

% Regularization parameter penalizing measurement error
gamma = 5;

% Solver tolerance
tol = 1e-3;

Cost_cell = cell(1); Cost_cell{1} = CostMat;
fprintf('\n')
fprintf('----------------------------------------------\n')
fprintf('Solving OMT tracking problem with dynamics...\n')
[Phi,transport_plan_cell,var_args_out] = ...
    multimarginal_tracking_sinkhornnewton(operator_cell,adjoint_cell,Jacobian_cell,r_cell_real,Cost_cell, epsilon,gamma,tol);
fprintf('----------------------------------------------\n')
pause(1)

%% Solve OMT problem without dynamics (no velocity state)

% We only have the postion state: covariance operator and related operators
% can be directly represented as matrices.
operator_cell_static = cell(1,length(r_cell_real));
adjoint_cell_static = cell(1,length(r_cell_real));
Jacobian_cell_static = cell(1,length(r_cell_real));
for kcell = 1:length(r_cell_real)
    G_operator = @(mu) ACell_real{kcell}*mu;
    operator_cell_static{kcell} = G_operator;
    G_adjoint = @(mu) ACell_real{kcell}'*mu;
    adjoint_cell_static{kcell} = G_adjoint;
    G_Jacobian = @(mu) ACell_real{kcell}*diag(mu)*ACell_real{kcell}';
    Jacobian_cell_static{kcell} = G_Jacobian;
end

ett_theta = ones(length(gridTheta),1);
CostMat_no_dyn = abs(gridTheta*ett_theta'-ett_theta*gridTheta').^2;
Cost_cell_static = cell(1,1);
Cost_cell_static{1} = CostMat_no_dyn;
eps_no_dyn = .1;
gamma_no_dyn = 30;

fprintf('\n')
fprintf('----------------------------------------------\n')
fprintf('Solving OMT tracking problem without dynamics...\n')
[Phi_no_dyn,transport_plan_cell_static,~] = ...
    multimarginal_tracking_sinkhornnewton(operator_cell_static,adjoint_cell_static,...
    Jacobian_cell_static,r_cell_real,Cost_cell_static, eps_no_dyn,gamma_no_dyn,tol);
fprintf('----------------------------------------------\n')
pause(1)
%% Interpolate trajectory based on computed transport plans: dynamic model

number_of_points = 10; % number of points between each observation time
fprintf('\n')
fprintf('----------------------------------------------\n')
fprintf('Interpolate trajectory from transport plan, dynamic (a bit brute force)\n')
pause(1)
[interpolant_theta,interpolant_v] = interpolate_from_transport_cell(transport_plan_cell,...
    gridTheta,gridV,number_of_points);
fprintf('----------------------------------------------\n')

%% Interpolate trajectory based on computed transport plans: static model

fprintf('----------------------------------------------\n')
fprintf('Interpolate trajectory from transport plan, static\n')
[interpolant_theta_static] = interpolate_from_transport_cell_static(transport_plan_cell_static,...
    gridTheta,number_of_points);
fprintf('----------------------------------------------\n')

%% Plot estimates

% Plot estimate using dynamic model as well as static model
plot_estimate

%%