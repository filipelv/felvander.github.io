%% Example script for barycenter problem
%
% This script runs the example in Section 6.2 of 
% "Multi-marginal optimal transport using partial information with
% applications in robust localization and sensor fusion", 2020, Elvander et
% al.
%

clc,clear,close all
addpath('aux_funcs_barycenter')
% power of source signals
source_sigma2_global = 100;
% sensor noise power
noise_sigma2 = 10;
% number of snapshots for estimating array covariance matrices
nbrSnapshots = 500;

% Generate data
generate_array_data

%% Setup grid on which to solve OMT problem

n=300; % nbr of grid points in each of the two dimensions
ggrid = linspace(-1,1,n)';
ett=ones(n,1); % vector of ones

Grid1=kron(ggrid, ett)';
Grid2=kron(ett,ggrid)';
Grid=[Grid1; Grid2];

% Choose the cost to be squared Euclidean distance. In this case, the
% two-dimensional cost is the the sum of the one-dimensional costs (per
% coordinate, see Remark 4).

% One-dimensional cost of transport
grid1D=ggrid';
Cost1D= (sum(grid1D.^2,1)'*ett' -2*(grid1D'*grid1D)+ ett*sum(grid1D.^2,1))';

% The cost can be decoupled along the two dimensions.
CostCell = cell(2,1);
% Same matrix Cost1D in both dimensions as the grid is the same.
CostCell{1} = Cost1D; CostCell{2} = Cost1D;

%% Misalignment of elliptical array

misAlignment = 10*pi/180*5/6;

%% Compute steering matrices and covariance operators

% For the linear array, no error in prior knowledge
arrayMat2_assumed = arrayMat2;
[Steering_Matrix_linear, G_linear]=steering_mat_and_operator_spherical_wave(Grid, arrayMat2_assumed, lambda,d_dim);

% For elliptical array, prior knowledge is erroneous
R = [cos(misAlignment),-sin(misAlignment);sin(misAlignment),cos(misAlignment)];
mean_pos = mean(arrayMat1,2);
arrayMat1_assumed = R*(arrayMat1-repmat(mean_pos,1,size(arrayMat1,2)))+repmat(mean_pos,1,size(arrayMat1,2));
[Steering_Matrix_ellips, G_ellips]=steering_mat_and_operator_spherical_wave(Grid, arrayMat1_assumed, lambda,d_dim);

%% Setup for OMT barycenter problem

% Collect covariance operators
GCell = cell(2,1);
GCell{1} = G_ellips;
GCell{2} = G_linear;


% Penalty parameter for measurement error
gamma = .01;

% Entropy regularization parameter
% If numerical problems appear, try increasing this parameter.
epsilon = 2e-3;

% Solver tolerance
tol = 5e-2;
%% Solve OMT problem

fprintf('\n')
fprintf('----------------------------------------------\n')
fprintf('Solving OMT barycenter problem...\n')
[Phi,Phi_margins] = multimarginal_barycenter_sinkhornnewton(GCell,SCMcell,CostCell,epsilon,gamma,tol);
fprintf('----------------------------------------------\n')
barycenter_spectrum = reshape(Phi,n,n);
ellips_array_spectrum = reshape(Phi_margins(:,1),n,n);
linear_array_spectrum = reshape(Phi_margins(:,2),n,n);

%% Plot estimates
do_zoomed_in = 0;
plot_estimates
