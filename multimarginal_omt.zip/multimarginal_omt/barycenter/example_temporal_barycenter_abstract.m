clc,clear,close all

% Barycenter example with two temporal spectra corresponding to 
% autoregressive processes. Here, transport on the unit circle is modeled.

%%%%%%%%%%%%%%%
% This version: 9 November 2021.
%%%%%%%%%%%%%%%%
%
% NOTE: this implementation uses abstract representation of covariance
% operators.
%%%%%%%%
rng(2*pi)
addpath('aux_funcs_barycenter')
% set to 1 if covariance function is to be estimated from realizations
noisy_data = 1;

if noisy_data
    nbr_samples = 300; % number of samples used to estimate covariance sequence
    burn_in = 10000; % burn-in for filtered data to reach stationarity
end

% Parameters for first process
angles1 = pi*[1/20,1/7,1/3];
amps1 = [.9,0.95,0.95];
p1 = amps1.*exp(1i*angles1);
ar1 = poly(p1)';

% Parameters for second process
angles2 = pi*(1/5+[1/10,1/5,1/3]);
amps2 = [.95,0.92,0.95];
p2 = amps2.*exp(1i*angles2);
ar2 = poly(p2)';

% Function yielding corresponding spectra
spec_func = @(theta,ar_coeffs) 1./abs(exp(1i*theta*(0:(length(ar_coeffs)-1)))*ar_coeffs).^2;

N_theta = 1001;
theta_grid = linspace(-pi,pi,N_theta)';
dtheta = theta_grid(2)-theta_grid(1);

% Compute spectra and normalize
Phi1 = spec_func(theta_grid,ar1);
Phi2 = spec_func(theta_grid,ar2);
sigma21 = (sum(Phi1)*dtheta);
Phi1 = Phi1/sigma21;
sigma22 = (sum(Phi2)*dtheta);
Phi2 = Phi2/sigma22;

figure(1)
plot(theta_grid,Phi1,'linewidth',1.5)
hold on
plot(theta_grid,Phi2,'linewidth',1.5)
hold off
grid on
xlabel('\theta'),xlim([-Inf,Inf])
title('Spectra of processes')

%% Generate data

Afunc = @(theta_grid,tau) exp(1i*tau*theta_grid')/2/pi*(theta_grid(2)-theta_grid(1));
tau_max = 30;
tau_vec = (0:tau_max)';
A = Afunc(theta_grid,tau_vec);

if noisy_data
    e1 = 1/sqrt(2*sigma21)*randn(burn_in+nbr_samples,2)*[1;1i];
    e2 = 1/sqrt(2*sigma22)*randn(burn_in+nbr_samples,2)*[1;1i];
    
    y1 = filter(1,ar1,e1); y1 = y1(burn_in+1:end);
    y2 = filter(1,ar2,e2); y2 = y2(burn_in+1:end);
    r1 = covf_compatibility(y1,tau_max+1).';
    r2 = covf_compatibility(y2,tau_max+1).';
    
else
    % Theoretical covariances
    r1 = A*Phi1;
    r2 = A*Phi2;
end
R1 = toeplitz(conj(r1));
R2 = toeplitz(conj(r2));
%% Compute covariance operators used for inference

N_theta2 = 2001;
theta_grid2 = linspace(-pi,pi,N_theta2)';
dtheta2 = theta_grid2(2)-theta_grid2(1);
A_inference = Afunc(theta_grid2,tau_vec)/dtheta2*2*pi;

% Operator mapping spectrum to vectorized covariance matrix
Gamma=zeros(length(tau_vec)^2,N_theta2);
for k=1:N_theta2
    Gamma(:,k) = kron(conj(A_inference(:,k)),A_inference(:,k))*dtheta/2/pi;
end

%% Dimension reduction of data and operators

% Collect covariance operators
GCell = cell(2,1);
GCell{1} = Gamma;
GCell{2} = Gamma;
RCell = cell(2,1); RCell{1} = R1; RCell{2} = R2;

% Yields vectorized real covariance, and corresponding operators
[ r_cell_real, GCell_real ] = TransformData( RCell, GCell );

% Define corresponding operator function handles
operator_cell = cell(1,length(r_cell_real));
adjoint_cell = cell(1,length(r_cell_real));
Jacobian_cell = cell(1,length(r_cell_real));
for kcell = 1:length(r_cell_real)
    G_operator = @(mu) GCell_real{kcell}*mu;
    operator_cell{kcell} = G_operator;
    G_adjoint = @(mu) GCell_real{kcell}'*mu;
    adjoint_cell{kcell} = G_adjoint;
    nbr_covs = size(GCell_real{kcell},1);
    G_Jacobian = @(mu) (GCell_real{kcell}.*repmat(mu(:).',nbr_covs,1))*GCell_real{kcell}';
    Jacobian_cell{kcell} = G_Jacobian;
end


%% OMT barycenter computation
ett_theta = ones(length(theta_grid2),1);
% Cost of transport: cosine distance on unit circle
Cost_mat = abs(exp(1i*theta_grid2)*ett_theta'-ett_theta*exp(1i*theta_grid2')).^2;

% One-dimensional cost function, does not need to be decoupled.
CostCell = cell(1,1); CostCell{1} = Cost_mat;

% Penalty parameter for measurement error
gamma = 1e3;

% Entropy regularization parameter
% If numerical problems appear, try increasing this parameter.
epsilon = 1e-2;

% Solver tolerance
tol = 1e-1;

% Solve OMT problem
fprintf('\n')
fprintf('----------------------------------------------\n')
fprintf('Solving OMT barycenter problem...\n')
[Phi,Phi_margins] = multimarginal_barycenter_abstract_sinkhornnewton(operator_cell,adjoint_cell,Jacobian_cell,...
    r_cell_real,CostCell,epsilon,gamma,tol);
fprintf('----------------------------------------------\n')



figure(2)
plot(theta_grid2,Phi_margins(:,1),'--','linewidth',1.5)
hold on
plot(theta_grid2,Phi_margins(:,2),'--','linewidth',1.5)
plot(theta_grid2,Phi,'k','linewidth',2)
hold off
grid on
legend('estimate, first process','estimate, second process','barycenter')
xlabel('\theta'),xlim([-Inf,Inf])
if noisy_data
    title('Barycenter from estimated covariances') 
else
   title('Barycenter from theoretical covariances') 
end