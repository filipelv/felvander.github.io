function [Y,SCM,Rtheo] = simulate_array_theoretical(Steering_Matrix,source_sigma2,...
    noise_sigma2,nbrSnapshots)

nbrSensors = size(Steering_Matrix,1);
nbrSources = length(source_sigma2);

if nbrSources~=size(Steering_Matrix,2)
    error('source power specification and steering matrix size not consistent')
end

Rtheo = Steering_Matrix*diag(source_sigma2)*Steering_Matrix' + noise_sigma2*eye(nbrSensors);

source_SIGMA2 = repmat(source_sigma2(:),1,nbrSnapshots);
X = sqrt(source_SIGMA2/2).*...
    (randn(nbrSources,nbrSnapshots)+1i*randn(nbrSources,nbrSnapshots));
E = sqrt(noise_sigma2/2)*...
    (randn(nbrSensors,nbrSnapshots)+1i*randn(nbrSensors,nbrSnapshots));

Y = Steering_Matrix*X + E;

SCM = Y*Y'/nbrSnapshots;
end