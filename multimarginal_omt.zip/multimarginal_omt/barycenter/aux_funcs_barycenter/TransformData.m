function [ RCell_real, ACell_real ] = TransformData( RCell, ACell )
%Transform Covariance and Steering Matrices to real numbered vectors 

nbrOfMatrices=length(RCell);




for kMat = 1:nbrOfMatrices
    
    R = RCell{kMat};%conj(RCell{kMat});%R = conj(RCell{kMat});
    A = ACell{kMat};
    
    n= size(R,1);
    Ngrid =size(A,2);
    
    R_real=zeros(n);
    A_real=zeros(n,Ngrid);
    for i=1:n
        R_real(i,i) = real(R(i,i));
        A_real((i-1)*n+i, : ) = real(A((i-1)*n+i, :));
        for j=1:i-1
            R_real(j,i) = real(R(j,i));
            R_real(i,j) = imag(R(i,j));
            A_real((i-1)*n+j, : ) = real(A((i-1)*n+j, :));
            A_real((j-1)*n+i, : ) = imag(A((j-1)*n+i, :));
        end
    end
    
    R_real=real(reshape(R_real,n^2,1));
    
    % Delete dependencies in A matrix
%     k=1;
%     for j=1:n^2
%         if rank(A_real(1:k,:))< k
%             A_real(k,:)=[];
%             R_real(k)=[];
%         else
%             k=k+1;
%         end
%     end
    [U,~,~] = svd(A_real,'econ');
    
    rankA=rank(A_real);
    
    U=U(:,1:rankA);
    
    RCell_real{kMat}=U'*R_real;
    ACell_real{kMat}=U'*A_real;
    
    %disp(['Data transformation to real numbers reduces dimension from ', ...
    %    num2str(n^2), ' to ', num2str(rankA)])
    
end





end

