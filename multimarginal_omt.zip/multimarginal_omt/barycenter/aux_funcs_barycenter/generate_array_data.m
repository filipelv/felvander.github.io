% Illustration of scenario

load('array_scenario_data')

nbrSources = size(source_pos,2);
rng(2*pi)

for kMic = 1:size(arrayMat1,2)
    plot(arrayMat1(1,kMic),arrayMat1(2,kMic),'bo','Linewidth',1.5),hold on
end

for kMic = 1:size(arrayMat2,2)
    plot(arrayMat2(1,kMic),arrayMat2(2,kMic),'kx','Linewidth',1.5),hold on
end

for kSource = 1:size(source_pos,2)
    plot(source_pos(1,kSource),source_pos(2,kSource),'r+','Linewidth',1.5)
end
hold off

%% Set global parameters


c = 340; % Speed of sound/propagation
carrier_freq = 3400; % Carrier frequency in Hz
lambda = c/carrier_freq; % Wavelength

% Simulation parameters
source_sigma2 = source_sigma2_global*ones(size(source_pos,2),1);

%% Generate data

d_dim = 2; % ambient dimension
source_pos_simul = [[-0.075;-0.075],[-.4;-.2]];

% Get steering matrices for true sources
[Steering_Matrix_ellips_simul, ~]=steering_mat_and_operator_spherical_wave(source_pos_simul, arrayMat1, lambda,d_dim);
[Steering_Matrix_linear_simul, ~]=steering_mat_and_operator_spherical_wave(source_pos_simul, arrayMat2, lambda,d_dim);

% Generate data
[~,SCM_ellips,~] = simulate_array_theoretical(Steering_Matrix_ellips_simul,source_sigma2,...
    noise_sigma2,nbrSnapshots);

[~,SCM_linear,~] = simulate_array_theoretical(Steering_Matrix_linear_simul,source_sigma2,...
    noise_sigma2,nbrSnapshots);
SCMcell{1} = SCM_ellips;
SCMcell{2} = SCM_linear;

% Remove true sterring matrices
clear Steering_Matrix_Sphere_simul
clear Steering_Matrix_array_simul

