function [Steering_Matrix, Gamma]=steering_mat_and_operator_spherical_wave(Grid, Sensor_Array, wave_length,d_dim)
%
% Computes steering vectors and covariance operators for spherical waves in
% dimension d_dim.
%
%%%%%%%%%% INPUT %%%%%%%%%%%%%
% Grid          -       grid of points for which the steering vectors and
%                       covariance oprerators will be computed. This should
%                       be given as a matrix of size d_dim \times N, where
%                       d_dim is the ambient dimension (2 or 3), and N is
%                       the number of grid points.
% Sensor_array  -       coordinates of the the sensor array, give as a
%                       matrix of size d_dim \times No_Sensors, where
%                       No_sensors is the number of sensors. Each column
%                       corresponds to the coordinates of a sensor.
% wave_length   -       wavelength relative to the propagation speed of the
%                       medium.
% d_dim         -       ambient dimension, scalar equal to 2 or 3.
%
%
%%%%%%%%%% OUTPUT %%%%%%%%%%%%%
% Steering_Matrix       -       steering matrix of size No_Sensors\times N,
%                               with each column being a steering vector
%                               corresponding to a corresponding grid
%                               point.
% Gamma                 -       the covariance operator represented as a
%                               matrix, mapping spatial spectra to
%                               vectorized covariance matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%
% This version: 7 November 2021.
%%%%%%%%%%%%%%%%%%%%%%%%%%

if d_dim~=2 && d_dim~=3
   error('d_dim must be either 2 or 3') 
end

No_Sensors=size(Sensor_Array, 2);
N=size(Grid, 2);

if size(Sensor_Array,1)~=d_dim
   error('the sensor array is not in R^d_dim') 
end
if size(Grid,1)~=d_dim
   error('the grid is not in R^d_dim') 
end

ett_grid = ones(N,1);
ett_sensors = ones(No_Sensors,1);
Dist_Matrix=sqrt(sum(Grid.^2,1)'*ett_sensors' -2*Grid'*Sensor_Array+ ett_grid*sum(Sensor_Array.^2,1))';

% Steering matrix
Steering_Matrix=exp(-2*pi*1i*Dist_Matrix/wave_length)./(Dist_Matrix+1e-10).^((d_dim-1)/2);

% Covariance operator: operator from spatial spectrum to vectorized
% covariance matrix
Gamma=zeros(No_Sensors^2,N);
for k=1:N
    Gamma(:,k)=kron(conj(Steering_Matrix(:,k)),Steering_Matrix(:,k));    
end
end



