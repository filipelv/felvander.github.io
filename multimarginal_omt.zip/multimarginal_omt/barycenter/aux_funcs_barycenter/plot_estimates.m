%% Plot barycenter

figure(1)
Est_vec_plot = Phi/max(Phi);
Est_vec_plot(Est_vec_plot<0.005) = NaN;
scatter(Grid(1,:),Grid(2,:),15,Est_vec_plot,'filled')

figure(1)
hold on

for kMic = 1:size(arrayMat1,2)
    h1 = plot(arrayMat1(1,kMic),arrayMat1(2,kMic),'bo','MarkerSize',6,'Linewidth',1.5);,hold on
end

for kMic = 1:size(arrayMat2,2)
    h2 = plot(arrayMat2(1,kMic),arrayMat2(2,kMic),'bx','MarkerSize',8,'Linewidth',1.5);,hold on
end
for kSource = 1:size(source_pos,2)
    hs = plot(source_pos_simul(1,kSource),source_pos_simul(2,kSource),'g+','MarkerSize',10,'Linewidth',2,...
        'color',[0 .8 0]);
end
diffTrue = 10*(arrayMat1(:,1) - array1center);
ho1 = quiver(array1center(1),array1center(2),diffTrue(1),diffTrue(2),0,'b',...
    'linewidth',1.5);

diffAssumed = 10*(arrayMat1_assumed(:,1) - array1center);
hoa1 = quiver(array1center(1),array1center(2),diffAssumed(1),diffAssumed(2),0,'k',...
    'linewidth',1.5);
hVec = [h1,h2,ho1,hoa1,hs];
strCell = {'array 1','array 2','array 1, orientation','array 1, assumed orientation','sources'};
legend(hVec,strCell,'Location','Northeast')
hold off
colorbar
colormap(flipud(gray))
xlabel('x-position'),ylabel('y-position')

xlim([-2,1.5]),ylim([-2,1.5])
grid on

if do_zoomed_in
    xlim([-.7,.4]),ylim([-.7,.4])
else
    xlim([-2,1.5]),ylim([-2,1.5])
end
title('Spectrum, barycenter')
%% Plot spectrum for elliptical array

figure(2)
Est_vec_plot = Phi_margins(:,1);
Est_vec_plot = Est_vec_plot/max(Est_vec_plot);
Est_vec_plot(Est_vec_plot<0.001) = NaN;
scatter(Grid(1,:),Grid(2,:),15,Est_vec_plot,'filled')

figure(2)
hold on

for kMic = 1:size(arrayMat1,2)
    h1 = plot(arrayMat1(1,kMic),arrayMat1(2,kMic),'bo','MarkerSize',6,'Linewidth',1.5);,hold on
end

for kMic = 1:size(arrayMat2,2)
    h2 = plot(arrayMat2(1,kMic),arrayMat2(2,kMic),'bx','MarkerSize',8,'Linewidth',1.5);,hold on
end
for kSource = 1:size(source_pos,2)
    hs = plot(source_pos_simul(1,kSource),source_pos_simul(2,kSource),'g+','MarkerSize',10,'Linewidth',2,...
        'color',[0 .8 0]);
end
diffTrue = 10*(arrayMat1(:,1) - array1center);
ho1 = quiver(array1center(1),array1center(2),diffTrue(1),diffTrue(2),0,'b',...
    'linewidth',1.5);

diffAssumed = 10*(arrayMat1_assumed(:,1) - array1center);
hoa1 = quiver(array1center(1),array1center(2),diffAssumed(1),diffAssumed(2),0,'k',...
    'linewidth',1.5);
hVec = [h1,h2,ho1,hoa1,hs];
strCell = {'array 1','array 2','array 1, orientation','array 1, assumed orientation','sources'};
legend(hVec,strCell,'Location','Northeast')
hold off
colorbar
colormap(flipud(gray))
xlabel('x-position'),ylabel('y-position')

if do_zoomed_in
    xlim([-.7,.4]),ylim([-.7,.4])
else
    xlim([-2,1.5]),ylim([-2,1.5])
end
grid on
title('Spectrum, elliptical array')
%% Spectrum linear array
figure(3)
Est_vec_plot = Phi_margins(:,2);
Est_vec_plot = Est_vec_plot/max(Est_vec_plot);
Est_vec_plot(Est_vec_plot<0.001) = NaN;
scatter(Grid(1,:),Grid(2,:),15,Est_vec_plot,'filled')

figure(3)
hold on

for kMic = 1:size(arrayMat1,2)
    h1 = plot(arrayMat1(1,kMic),arrayMat1(2,kMic),'bo','MarkerSize',6,'Linewidth',1.5);,hold on
end

for kMic = 1:size(arrayMat2,2)
    h2 = plot(arrayMat2(1,kMic),arrayMat2(2,kMic),'bx','MarkerSize',8,'Linewidth',1.5);,hold on
end
for kSource = 1:size(source_pos,2)
    hs = plot(source_pos_simul(1,kSource),source_pos_simul(2,kSource),'g+','MarkerSize',10,'Linewidth',2,...
        'color',[0 .8 0]);
end
diffTrue = 10*(arrayMat1(:,1) - array1center);
ho1 = quiver(array1center(1),array1center(2),diffTrue(1),diffTrue(2),0,'b',...
    'linewidth',1.5);

diffAssumed = 10*(arrayMat1_assumed(:,1) - array1center);
hoa1 = quiver(array1center(1),array1center(2),diffAssumed(1),diffAssumed(2),0,'k',...
    'linewidth',1.5);
hVec = [h1,h2,ho1,hoa1,hs];
strCell = {'array 1','array 2','array 1, orientation','array 1, assumed orientation','sources'};
legend(hVec,strCell,'Location','Northeast')
hold off
colorbar
colormap(flipud(gray))
xlabel('x-position'),ylabel('y-position')

if do_zoomed_in
    xlim([-.7,.4]),ylim([-.7,.4])
else
    xlim([-2,1.5]),ylim([-2,1.5])
end
grid on
title('Spectrum, linear array')
%%

figure(1)