function [Phi,Phi_margins,var_args_out] = ...
    multimarginal_barycenter_abstract_sinkhornnewton(operator_cell,adjoint_cell,Jacobian_cell,r_cell,Cost_cell,epsilon,gamma,tol)
%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementation of the multi-marginal barycenter problem in
%
% "Multi-marginal optimal transport using partial information with
% applications in robust localization and sensor fusion", 2020, Elvander et
% al, Section 3.1, as described in Section 3.1 and 5.2.
% (centrally decoupling cost function).
%
% Implementation: Filip Elvander and Isabel Haasler.
%%%%%%%%%%%%%%%%%% INPUT %%%%%%%%%%%%%%%%%%%
% operator_cell         -   cell of length N_marginals. Each cell should
%                           contain a function handle to the operator G_t,
%                           for t = 1,...,N_marginals. If G_t can be
%                           represented as a matrix G, simply give the
%                           handle as G_t = @(x) G*x.
% adjoint_cell          -   cell of length N_marginals, with each cell
%                           containing a function handle to the adjoint
%                           operator of G_t. If G_t can be represented as a
%                           matrix G, simply give the adjoint as @(y) G'*y.
% Jacobian_cell         -   cell of length N_marginals. Each cell should
%                           contain afunction handle to the part
%                           G_t diag(x) G_t^T of the Jacobian below
%                           equation (39). If the operator G_t can be
%                           represented as a matrix G, simply give the
%                           handle as @(x) G*diag(x)*G';
% r_cell                -   cell of length N_marginals, where each element
%                           r_t, for t = 1,...,N_marginals, is vectorized
%                           and dimension reduced covariance matrix R_t.
%                           Note here that r_t should be in the range of
%                           G_t, i.e., G_t maps spectra to r_t.
%                           NOTE: use the auxilliary function TransformData
%                           to get this.
% Cost_cell     -       cell length D containing the cost matrix C. If C
%                       can be decoupled in D dimensions as in Remark 4,
%                       then the respective element should contain the
%                       corresponding component.
% epsilon       -       entropy regularization parameter. If the method
%                       suffers numerical issues, try increasing this
%                       parameter.
% gamma         -       penalty parameter for covariance error.
%
%%%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%%%%%%%%
% Phi           -       the spectral barycenter, vector of length Ngrid.
% Phi_margins   -       the marginal spectra, corresponding to each
%                       covariance matrix. Matrix of size
%               -       Ngrid-times-N_marginals.
% var_args_out  -       struct containing matrix U with vectors u_k as well
%                       as cell KUCell containing products K u_k, cell
%                       KCell containing the D components of K, and cell
%                       KCell_transposed containing the D components of
%                       K^T. This can be used for computing all projections.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% NOTE: this implementation uses abstract formulation for covariance
% operatos G_t and their adjoints.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 9 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% NOTE: tensorlab used for efficient computations for structured cost
% matrices
addpath('tensorlab')

do_print = 1;

N_grid = 1;
for kdim = 1:length(Cost_cell)
    N_grid = N_grid*size(Cost_cell{1},2);
end
N_marginals=length(r_cell);

% Initialze variables u_k and lambda_k
U=zeros(N_grid,N_marginals);
LCell=cell(1,N_marginals);
for k_margin=1:N_marginals
    LCell{k_margin}= zeros(size(r_cell{k_margin}));
    U(:,k_margin) = exp(adjoint_cell{k_margin}(LCell{k_margin})/epsilon);
end

%%%% Compute K matrix %%%%%%%%%%
% If K can be decomposed according to Remark 4, then store the different
% compoents in a cell
K_cell = cell(size(Cost_cell));
for k_dim = 1:length(K_cell)
    K_cell{k_dim} = exp(-Cost_cell{k_dim}/epsilon);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute transposed cost matrices. Used for computing v_k %%%%%%
K_cell_transposed = cell(size(K_cell));
for k_dim = 1:length(K_cell)
    K_cell_transposed{k_dim} = K_cell{k_dim}';
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Intialize products K u_k %%%%%
KUCell={};
KUCell = compute_KUCell_barycenter_internal(KUCell,K_cell,U,0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% start updating the first marginal
k_margin=1;
pass_direction=0;
dU=1;
U_old=U;

% iteration counter
it=0;
% maximum number of iterations
max_iter = 10000;

%%%%%%%%%%%% SINKHORN-NEWTON METHOD %%%%%%%%%%%%%%%%%%
%%%%%%% Iterative update of u_k and lambda_k %%%%%%%%%%%%
while norm(dU)/norm(U)> tol || it <5
    
    it=it+1;
    if do_print && mod(it,100)==0
        fprintf('Sinkhorn iteration %d, variable change %.3E, tolerance %.3E\n',it,norm(dU)/norm(U),tol)
    end
    %%%% Decide pass direction: pass_direction = 1 or pass_direction = -1.
    if it==1
        pass_direction=1;
    end
    %%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%% Compute vector v_k using Proposition 3 %%%%%%
    V = multimarginal_barycenter_V_internal(KUCell,K_cell_transposed,k_margin);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%% Compute lambda_k %%%%%%%%%%%%%%%%%%%%%%%%
    LCell{k_margin} = OMT_Newton_abstract_internal(operator_cell{k_margin},adjoint_cell{k_margin},Jacobian_cell{k_margin},...
        r_cell{k_margin},V, LCell{k_margin}, epsilon, gamma);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%% Compute u_k %%%%%%%%%%%%%%%%%%%%%%%%
    U(:,k_margin) = exp(adjoint_cell{k_margin}(LCell{k_margin})/epsilon);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%% Update product K u_k %%%%%%%%%%%%%%%%%
    KUCell = compute_KUCell_barycenter_internal(KUCell,K_cell,U,k_margin);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%% If k == N_marginals, another full pass has been performed %%%%%
    if k_margin==N_marginals
        pass_direction=-1;
        dU=U_old-U;
        U_old=U;
    end
    if k_margin==1
        pass_direction=1;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if it>max_iter
        disp('Did not converge')
        break
    end
    
    %%% Update next variable %%%%%%%%
    k_margin=k_margin+pass_direction;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['Number of Sinkhorn iterations: ', num2str(it)])

%%%%%% Compute barycenter spectrum as well as marginal spectra %%%%%
Phi = project_on_margin_barycenter_internal(U,KUCell,K_cell_transposed,0);
Phi_margins = zeros(length(Phi),N_marginals);
for k_margin = 1:N_marginals
    Phi_margins(:,k_margin) = project_on_margin_barycenter_internal(U,KUCell,K_cell_transposed,k_margin);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Assign additional output %%%%%%%%%
var_args_out = struct;
var_args_out.U = U;
var_args_out.KUCell = KUCell;
var_args_out.KCell = K_cell;
var_args_out.KCell_transposed = K_cell_transposed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%%%%%%%%%%%%%%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%% INTERNAL SOUBROUTINES %%%%%%%%%%%%
%%%%%%%%%%%%
function V = multimarginal_barycenter_V_internal(KUCell,KCell_transposed,k)
%%%%%%%%%%%%%%%%%%%% BARYCENTER PROBLEM  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implements the computations of v_k = P_k(M)./u_k, where P_k is
% the projection on the k:th marginal and M is the transport plan tensor
% for the case of a centrally decoupling cost (barycenter case).
%
% Note that M is represented as M = K \odot U, where K is the cost tensor
% and U is the variable tensor.
%
% The projection is implemented according to Proposition 3.
%
% Note: the first column of V corresponds to the barycenter.
%
%%%%%%%%%% INPUT %%%%%%%%%%%
% KUCell        -   cell of length N_observations, where element k is the
%                   matrix-vector product Ku_k, with K being the cost
%                   matrix K = exp(-C/epsilon), with C being the defining
%                   cost matrix between barycenter and marginal.
% KCell         -   cell containing the (potentially) decoupled
%                   representation of the cost matrix K for efficient
%                   computation (see Remark 4).
% k             -   interger in the range [0, N_observations], determining
%                   which projection is computed. Here "0" corresponds to
%                   the barycenter, whereas k \in [1,N_observations]
%                   corresponds to the margin of the k:th observation.
%
%%%%%%%%%%% OUTPUT %%%%%%%%%%%
%
% V         -       vector of size N-times-1, where N is the number of
%                   points used to grid the margin. This is P_k(M)./u_k.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: November 6, 2021.
% NOTE: fix so that KCell contains the transpose of K as to work for
% non-symmetric K. This should be enough?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
N_observations =length(KUCell);
%
%
% Note: u0 is a vector of ones.
V = ones(size(KUCell{1}));
%
% Compute products of Ku_j, excluding Ku_k.
for k_index = 1:k-1
    V = V.*(KUCell{k_index});
end
for k_index = k+1:N_observations
    V = V.*(KUCell{k_index});
end
%
% Note : k == 0 corresponds to projection on barycenter margin
if k>0
    V = Cost_multiplication_internal(KCell_transposed,V);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%
function lambda=OMT_Newton_abstract_internal(G_operator,G_adjoint,G_Jacobian,r,v,lambda0, epsilon, gamma)
%
%%%%%%%%%%%%%%%
% Newton method for solving equation (38).
% This method uses abstract representations of the operator G, its adjoint,
% and the corresponding part of the Jacobian. This allows for more
% efficient application than allowed by matrix representations.
%%%%%%%%%%%%%%%%%% INPUT %%%%%%%%%%%%%%%%%%%
% G_operator    -       function handle to operator G_t.
% G_adjoint     -       function handle to adjoint operator G_t^T
% G_Jabobian    -       function handle for computation G_t diag(x) G_t^T
% r             -       covariance vector, the measurement.
% v             -       vector depending on other variables.
% lambda0       -       initial value for lambda.
% epsilon       -       entropy regularization parameter.
% gamma         -       regularization parameter penalizing measurement
%                       error.
% tol           -       tolerance for solution.
%%%%%%%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%%%%%
% lambda        -       vector, solution to (38).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 8 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%
scaled_I = eye(length(r))/2/gamma;
lambda=lambda0;

Niter=100;
f=1;
it=0;
while norm(f)>1e-8 && it < Niter
    it=it+1;
    
    u = exp(G_adjoint(lambda)/epsilon);
    vu = v.*u;
    f = G_operator(vu)+lambda/2/gamma-r;
    H = G_Jacobian(vu)/epsilon+scaled_I;
    
    dlambda= -H\f;
    
    % linesearch
    dF = 1;
    lambda_o = lambda;
    F = norm(f);
    nn=1;
    
    while dF>0
        lambda = lambda_o+1/nn*dlambda;
        u = exp(G_adjoint(lambda)/epsilon);
        f = G_operator(v.*u)+lambda/2/gamma-r;
        F_new = norm(f);
        dF = F_new-F;
        nn=2*nn;
        if nn>1e3
            disp('Many line search iterations')
            break;
        end
    end
    
end

if it>10
    disp(['Many Newton iterations: ', num2str(it)])
end

if norm(f)>1e-6
    disp('Newton has not converged')
    [log(norm(f)), log(norm(dlambda)), norm(lambda)]
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
function KUCell = compute_KUCell_barycenter_internal(KUCell,KCell,U,k)
%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the terms K u_k, for k = 1,...,N_marginals, where N_marginals
% is the number of marginals, i.e., the number of observations.
% Note: for barycenter formulation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% INPUT %%%%%%%%%%%%%%
% KUCell        -       cell of length N_marginals containing products K u_k.
% KCell         -       cell containing the matrix K, potentially
%                       decomposed according to Remark 4. In this case, the
%                       different components of K populate the different
%                       elements of the cell.
% U             -       matrix with N_margins columns, each column
%                       corresponding to u_k, for k = 1,...,N_marginals.
% k             -       index indicating which factor K u_k to update. If
%                       in the range [1,N_marginals], then K u_k is updated.
%                       If k == 0, then all margins are updated (use this
%                       for initialization).
%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%
% KUCell        -       cell of length N_marginals containing products K u_k.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Note: Should work for unsymmetric Cost matrix now!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 7 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
N_marginals=size(U,2);
if k == 0 % Initialize KUCell
    for t=1:N_marginals
        KUCell{t} = Cost_multiplication_internal(KCell,U(:,t));
    end
else % Update KU product k
    KUCell{k} = Cost_multiplication_internal(KCell,U(:,k));
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%
function KU = Cost_multiplication_internal(KCell,U)
% Multiplicated each column in U as a tensor with Ndim dimensions with K
% from each dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Efficient computation of matrix-vector products Ku between a matrix K and
% a vector u when K can be decoupled as a tensor product
%
% K = K_1 \otimes K_2 \otimes ... \otimes K_{Ndim}
%
% where \otimes is the Kronecker product, and K_j are matrices of size
%
% (see Remark 4).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: 5 November 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
Ndim=length(KCell);

nbrOfMatrices=size(U,2);
for d=1:Ndim
    Ngrid(d)=size(KCell{d},2);
    Ngrid_full(d)=size(KCell{d},1);
end
N=prod(Ngrid_full);

noReshapeFlag = size(U,1)==Ngrid;
for kMat= 1:nbrOfMatrices
    if noReshapeFlag
        U_array=U(:,kMat);
    else
        U_array=reshape(U(:,kMat),Ngrid);
    end
    %U_array=reshape(U(:,kMat),Ngrid);
    temp=U_array;
    for d=1:Ndim
        temp=tmprod(temp,KCell{d},d);
    end
    %     KU(:,kMat)= vec(temp);
    KU(:,kMat)= reshape(temp,N,1);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
function proj_margin = project_on_margin_barycenter_internal(U,KUCell,KCell_transposed,k_margin)
%
%%%%%%%%%%%%%%%%%%%% BARYCENTER PROBLEM  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implements the projection P_k(M), which is the projection on the k:th
% marginal and M is the transport plan tensor for the case of a centrally
% decoupling cost (barycenter case).
%
% Note that M is represented as M = K \odot U, where K is the cost tensor
% and U is the variable tensor.
%
% The projection is implemented according to Proposition 3.
%
% Note: the first column of V corresponds to the barycenter.
%
%%%%%%%%%% INPUT %%%%%%%%%%%
% KUCell        -   cell of length N_observations, where element k is the
%                   matrix-vector product Ku_k, with K being the cost
%                   matrix K = exp(-C/epsilon), with C being the defining
%                   cost matrix between barycenter and marginal.
% KCell         -   cell containing the (potentially) decoupled
%                   representation of the cost matrix K for efficient
%                   computation (see Remark 4).
% k             -   interger in the range [0, N_observations], determining
%                   which projection is computed. Here "0" corresponds to
%                   the barycenter, whereas k \in [1,N_observations]
%                   corresponds to the margin of the k:th observation.
%
%%%%%%%%%%% OUTPUT %%%%%%%%%%%
%
% proj_margin      -      vector of size N-times-1, where N is the number
%                         of points used to grid the margin. This is
%                         P_k(M).
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version: November 6, 2021.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
if k_margin == 0
    proj_margin = multimarginal_barycenter_V_internal(KUCell,KCell_transposed,k_margin);
else
    proj_margin = U(:,k_margin).*multimarginal_barycenter_V_internal(KUCell,KCell_transposed,k_margin);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%

%%%%%%%%%%%% END INTERNAL SOUBROUTINES %%%%%%%%%%%%

